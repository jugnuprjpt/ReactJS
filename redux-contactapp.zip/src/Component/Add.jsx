import React from 'react'

function Add() {
  return (
    <h1>Hello World</h1>
  )
}

export default Add