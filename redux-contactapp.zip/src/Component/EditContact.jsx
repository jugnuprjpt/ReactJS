import React, { useState, useEffect } from "react";
import { Connect } from "react-redux";
import { useDispatch, useSelector } from "react-redux";
import { Link, useNavigate, useParams } from "react-router-dom";
import { toast } from "react-toastify";

const EditContact = () => {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [number, setNumber] = useState("");

  const { id } = useParams();
  const contacts = useSelector((state) => state);
  const dispatch = useDispatch;
  const navigate = useNavigate;
  const currentContact = contacts.find(
    (contact) => contact.id === parseInt(id)
  );

  useEffect(() => {
    if (currentContact) {
      setName(currentContact.name);
      setEmail(currentContact.email);
      setNumber(currentContact.number);
    }
  }, [currentContact]);

  const handleSubmit = (e) => {
    e.preventDefault();

    const checkEmail = contacts.find(
      (contact) => contact.id !== parseInt(id) && contact.email === email
    );

    const checkNumber = contacts.find(
      (contact) =>
        contact.id !== parseInt(id) && contact.number === parseInt(number)
    );

    if (!email || !number || !name) {
      return toast.warning("Please fills all the fields!");
    }
    if (checkEmail) {
      return toast.error("This email is already exist!");
    }
    if (checkNumber) {
      return toast.error("This number is already exist!");
    }
    const data = {
      id: parseInt(id),
      name,
      email,
      number,
    };
    // dispatch({ type: "UPDATE_CONTACT", payload: data });
    toast.success("Student updated sucessfully !!");
    navigate.push("/");
  };
  return (
    <div className="contianer">
      {currentContact ? (
        <>
          <h1 className="display-3 my-5 text-center">{id}Edit Student</h1>
          <div className="jj">
            <div
              className="col-md-6 shadow mx-auto p-5"
              style={{ backgroundColor: "cornflowerblue" }}
            >
              <form >
                <div className="form-group">
                  <input
                    type="text"
                    placeholder="name"
                    className="form-control"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </div>
                <br />
                <div className="form-group">
                  <input
                    type="email"
                    placeholder="Email"
                    className="form-control"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
                <br />
                <div className="form-group">
                  <input
                    type="number"
                    placeholder="phone-number"
                    className="form-control"
                    value={number}
                    onChange={(e) => setNumber(e.target.value)}
                  />
                </div>
                <br />
                <div className="form-group">
                  <input
                    type="button"
                    value="Update student"
                    className="btn btn-dark"
                    onClick={handleSubmit}
                  />
                  &nbsp; &nbsp;
                  <Link to="/" className="btn btn-danger mr-3">
                    Cancel
                  </Link>
                </div>
              </form>
            </div>
          </div>
        </>
      ) : (
        <h1 className="display-3 my-5 text-center">
          student contact with ID {id} not exists
        </h1>
      )}
    </div>
  );
};

export default EditContact;
