import { combineReducers } from "redux";
import cartItems from "./Reducers";


export default combineReducers({
    cartItems,

})