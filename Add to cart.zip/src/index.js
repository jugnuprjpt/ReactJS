import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import '@fortawesome/fontawesome-free/css/all.min.css';
import 'bootstrap-css-only/css/bootstrap.min.css';
import 'mdbreact/dist/css/mdb.css';
import { createStore } from 'redux';
import { createRoot } from "react-dom/client";
import { Provider } from 'react-redux';
import rootReducer from './Services/Reducers/Index'
import reportWebVitals from './reportWebVitals';

const store=createStore(rootReducer)
 console.warn ("store")

/* ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById('root') */
  
const rootElement = document.getElementById("root");
const root = createRoot(rootElement);
root.render(
  <Provider store={store}>
  < App/>
  </Provider>
  )
// ReactDOM.render(<MainRouter />,document.getElementById('root'));



reportWebVitals();
