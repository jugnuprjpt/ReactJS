import React from 'react';
import './App.css';
import Home from './Component/Home';
import HomeContainer from './Contains/HomeContainer';
/* import User from './User';
 */
function App() {
  return (
    <div className="App">
          
         <>
        {/*  <User data= {{name:"Jugnu", surname:"prajapati"}} /> */}
       {/*  <Home/> */}
        <HomeContainer></HomeContainer>
         </>
    </div>
  );
}

export default App;
