import React from "react";
import "./Home.css";
import { Link } from "react-router-dom";


function Home(props) {
  console.log(props.data)
  return (
    <>
      <div className="container">
        <div className="row">
          <div className="col-md-3">
            <img
              className="card-img-top-one"
              src="./images.png"
              alt="Card image cap"
            />
            <span className="number">{props.data.length}</span>
          </div>
        </div>
      </div>
      
       <div className="container">
        <div className="row">
          <div className="col-md-3">
            <div
              className="card"
              style={{ width: "25rem", height: "30rem", top: "100px" }}
            >
              <img
                className="card-img-top"
                src="./Potato.jpg"
                alt="Card image cap"
              />
              <div className="card-body">
                <h5 className="card-title">Potato</h5>
               
                <button onClick={() => {props.addToCartHandelar({pice:1000,name:'i phone 11'})}}
                  
                  className="btn btn-primary"
                  style={{ height: "50px", marginTop: "60px" }}
                >
                  Add to cart
                </button>
               

                <button
                  onClick={() => {props.removeToCartHandelar()}}
                  className="btn btn-secondary"
                  style={{ height: "50px", marginTop: "60px" }}

                  
                >
                  Remove to cart
                </button>
              </div>
            </div>
          </div>
        </div>
      </div> 
    </>
  );
}

export default Home;
