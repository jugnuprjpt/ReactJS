import React from "react";

const About = () => {
  return (
    <div style={{ fontSize: "20px", marginTop: "10px" }}>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam malesuada,
      turpis vel ornare laoreet, sem neque viverra quam, sed gravida purus arcu
      eu quam. Sed laoreet, turpis quis euismod fermentum, metus augue placerat
      ipsum, eu iaculis elit velit ut orci. Ut lectus enim, semper sit amet
      lorem a, tristique vestibulum tortor. Ut aliquam efficitur lorem, eget
      luctus leo venenatis ut. Quisque urna ligula, ullamcorper eu tempus eget,
      tempor eu enim. Sed ullamcorper gravida elit, vel egestas libero. Morbi
      sit amet leo ipsum. Donec id consectetur orci, id cursus nunc. Nullam
      metus nisl, suscipit id quam at, consequat mattis orci. Suspendisse
      accumsan, ligula et volutpat mollis, erat nunc aliquet enim, in efficitur
      lacus lacus eget urna. Ut mollis lectus est, non commodo velit blandit
      vitae. Suspendisse in mollis nibh. Nulla mollis nunc non mauris
      <br /> <br />
      pellentesque, faucibus dignissim est condimentum. Etiam condimentum id
      urna ac cursus. Fusce ac orci consectetur, accumsan felis in, convallis
      nulla. Ut sed accumsan tellus. Quisque porta velit at feugiat interdum.
      Curabitur iaculis, eros sed malesuada aliquet, nisi odio vulputate velit,
      eget malesuada augue elit eget orci. Vestibulum at elementum nulla, at
      tempor odio. Aenean tempus ac urna eu sodales. Aliquam sit amet ex
      tincidunt, ullamcorper velit sit amet, pharetra justo. Suspendisse blandit
      risus ex, at convallis libero tempor non. Nulla orci libero, vestibulum
      vel eleifend lacinia, elementum at tortor. Quisque ultricies felis vitae
      molestie aliquet. Sed sit amet dui semper, suscipit mi pulvinar, lacinia
      arcu. Morbi egestas mauris felis. Donec vitae orci luctus, imperdiet enim
      <br /> <br />
      ac, facilisis felis. Vivamus condimentum sollicitudin dolor nec rutrum.
      Quisque et odio eget eros tempus pulvinar rutrum a purus. Donec lorem
      tellus, euismod nec hendrerit et, fermentum id velit. Mauris lobortis sem
      vel tellus pretium, ac posuere leo ultrices. Phasellus ac lorem sed ante
      convallis cursus. Aenean malesuada, tortor eget molestie tempor, tortor
      sem aliquam orci, facilisis placerat ligula mauris eget arcu. Donec eu mi
      mattis, mollis dolor nec, blandit odio. Quisque id neque mattis enim
      ornare tincidunt sit amet sed dolor. Aenean porttitor luctus dapibus.
      Vestibulum nec viverra sapien, tincidunt eleifend neque.
    </div>
  );
};
export default About;
