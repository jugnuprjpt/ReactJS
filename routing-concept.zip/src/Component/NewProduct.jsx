import React from "react";

export const NewProduct = () => {
  return <div style={{ fontSize: "22px" }}>NewProduct</div>;
};
