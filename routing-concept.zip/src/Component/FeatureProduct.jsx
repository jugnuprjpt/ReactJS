import React from "react";

export const FeatureProduct = () => {
  return <div style={{ fontSize: "22px" }}>List of new product</div>;
};
