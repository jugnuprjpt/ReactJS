import React from 'react'

const About = () => {
  return (
    <>
    
        <section className="about">
        <div className='container-fluid'>
            <h3 className='head-about text-center'>About Us</h3>
            <div className='row rh'>
                <div className='col-md-6'>
                    <h3 className='about-title'>Our Story...</h3>
                    <p>
                    Gomatifood groundnut oil mill is established with aim to promote and to provode healthy, natural and 100% pure oil from best quality groundnut to customer with preserving inherent antioxidant, vitamin and mineral. Our motto is customer satisfaction is our priority.
                    </p>
                        
                    
                    <p>
                       sggdfgffffffffffffffffffffffffffffffffffffffff
                        ffffffffffffffffffffffffffffffffffffffffffffff
                        ffffffffffffffffffffffffffffffffffffffffffffff
                        sggdfgffffffffffffffffffffffffffffffffffffffff
                        ffffffffffffffffffffffffffffffffffffffffffffff
                        ffffffffffffffffffffffffffffffffffffffffffffff
                        sggdfgffffffffffffffffffffffffffffffffffffffff
                        ffffffffffffffffffffffffffffffffffffffffffffff
                        ffffffffffffffffffffffffffffffffffffffffffffff
                    </p>

                    <p>
                       sggdfgffffffffffffffffffffffffffffffffffffffff
                        ffffffffffffffffffffffffffffffffffffffffffffff
                        ffffffffffffffffffffffffffffffffffffffffffffff
                        sggdfgffffffffffffffffffffffffffffffffffffffff
                        ffffffffffffffffffffffffffffffffffffffffffffff
                        ffffffffffffffffffffffffffffffffffffffffffffff
                        sggdfgffffffffffffffffffffffffffffffffffffffff
                        ffffffffffffffffffffffffffffffffffffffffffffff
                        ffffffffffffffffffffffffffffffffffffffffffffff
                    </p>
                    
                </div>
                <div className='col-md-6'>
                    <div className='about-img-sec'>
                    <img src='https://c.ndtvimg.com/2021-09/et6srv6_masala-powder_625x300_17_September_21.png' className='img-fluid' alt='no img'/>
                    </div>
                </div>
            </div>
        </div>
        </section>
    </>
  )
}

export default About