import React from 'react'

const Payment = () => {
  return (
    <>
      <a href=""></a>
      <a href="https://wa.me/9586038778">Send Message</a>
    </>
  )
}

export default Payment