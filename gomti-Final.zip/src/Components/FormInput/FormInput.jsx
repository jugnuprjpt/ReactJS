import React from 'react'
import { Link } from 'react-router-dom'

const FormInput = () => {
  return (
    <>
        <h1>fdsfhjsbfvhjhjn</h1>
        <p>dfvgbfhjb</p>
        <Link to = "/Payment">
        <button>Jump next page</button>
        </Link>
    </>
  )
}

export default FormInput