import father from "../img/Coconet.jpg";
import mother from "../img/Coconet.jpg";
import son from "../img/natural.png";
import natural from "../img/natural.png";

const MyAPI = [
  { id: 1, image: father, title: "Baap" },
  { id: 2, image: mother, title: "Mata" },
  { id: 3, image: son, title: "Beta" },
  { id: 4, image: natural, title: "son" },
];

export default MyAPI;
