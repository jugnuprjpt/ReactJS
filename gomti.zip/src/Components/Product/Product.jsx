import React from 'react'

const Product = () => {
  return (
    <>
      <div className="head mt-5">
          <h1>Our Service</h1>
      </div>
      <div className="container d-flex mt-5 justify-content-around"  >
          <div className="col-md-3 border bg-primary" >
             
                  <img className = "mt-5"src="../img/commercial-review-pay.png" alt="" style={{width:"250px", height:"200px"}}/>
                  <h2 className = "ml-5 mt-2">Free Shiping</h2>
                  <p className = "ml-4">On order above Rs 1000 only</p>
            
          </div>
          {/* <div className="col-md-3 border bg-warning">
             
                  <img src="../img/commercial-review-pay.png" alt="" style={{width:"250px", height:"200px"}}/>
                  <h2 style={{marginLeft:"50px"}}>Free Shiping</h2>
                  <p style={{marginLeft:"28px"}}>On order above Rs 1000 only</p>
              </div>  */}
      </div>
      
    </>
  )
}

export default Product