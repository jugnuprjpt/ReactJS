import React from "react";
import { useState , useEffect} from "react";

const LogJu = () => {
  const initialvalue = { username: "", email: "", passward: "" };
  const [formfun, setFormFun] = useState(initialvalue);
  const [formError, setFormError] = useState({});
  const [isSubmit, setIsSubmit] = useState(false);

  const handleChange = (e) => {
     const {name, value} = e.target
     setFormFun({...formfun,[name]:value});
      console.log(e.target);

  };

   const handleSubmit = (e) =>{
     e.preventDefault();
     setFormError( validate(formfun));
     setIsSubmit(true);

   };
    
   useEffect (() => {
     console.log(formError);
     if (Object.keys (formError).length === 0 && isSubmit) {
       console.log(formfun);
     }
   } ,[formError]);
   const validate = (values) => {
     const errors = {};
     const regex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i; 
     if (!values.username) {
      errors.username = "username required";

     }
     if (!values.email) {
      errors.email = "email required";

     }
     if (!values.passward) {
      errors.passward = "passward required";

     }


   };

  return (
    <>
      <div className="container">
        <pre>{JSON.stringify(formfun, undefined, 2)}</pre>
        <form onSubmit={handleSubmit}>
          <h1>Login</h1>
          <div className="ui-divider">
            <div className="ui-form">
              <div className="field">
                <label htmlFor="">Name:-</label> &nbsp;
                <input
                  type="text"
                  name="username"
                  placeholder="Your name"
                  value={formfun.username}
                  onChange={handleChange}
                />
              </div>
              <div className="field">
                <label htmlFor="">Email:-</label> &nbsp;
                <input
                  type="text"
                  name="email"
                  placeholder="Your Email"
                  value={formfun.email}
                  onChange={handleChange}
                />
              </div>
              <div className="field">
                <label htmlFor="">Passward:-</label> &nbsp;
                <input
                  type="text"
                  name="passward"
                  placeholder="Passward"
                  value={formfun.passward}
                  onChange={handleChange}
                />
              </div>
              <button className="sbmt">submit</button>
            </div>
          </div>
        </form>
      </div>
    </>
  );
};

export default LogJu;
