import React, { useState } from "react";
import Card from "../Card/Card";
import MyAPI from "../../Api/MyAPI";

const Resuable = () => {
  const [apiData, setApiData] = useState(MyAPI);
  return (
    <>
      <h1 style={{textAlign:"center", marginTop:"40px"}}>Our Product</h1>
      <div className="container mt-5 ">
        <div className="row d-flex" /* style={{ display: "flex" }} */>
          {apiData.map((item) => (
            <Card key={item.id} title={item.title} source={item.image} />
          ))}
        </div>
      </div>
    </>
  );
};

export default Resuable;
