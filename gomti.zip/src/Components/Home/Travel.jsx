import React from 'react'

const Travel = () => {
  return (
    <>
     
    </>
  )
}

export default Travel
