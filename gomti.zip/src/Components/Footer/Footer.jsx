import React from "react";

const Footer = () => {
  return (
    <>
      <footer className="footer">
        <div className="footercontainer">
          <div className="container-fluid">
            <div className="row">
              <div className="col-12 col-lg pt-3 pt-xl-0">
                <a href="#" className="mb-3 d-block">
                  <img src="img/logo.png" alt="" />
                </a>
                <ul className="d-flex sociallinks pb-3 pb-xl-0">
                  <li>
                    <a href="#">
                      <i className="fab fa-facebook-f"></i>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i className="fab fa-linkedin-in"></i>
                    </a>
                  </li>

                  <li>
                    <a href="#">
                      <i className="fab fa-instagram"></i>
                    </a>
                  </li>

                  <li>
                    <a href="#">
                      <i className="fab fa-youtube"></i>
                    </a>
                  </li>
                </ul>
              </div>
              <div className="col-6 col-lg">
                <h4>Quick Links</h4>
                <ul className="footerlinks">
                  <li>
                    <a href="#"> Our Partners & Services </a>{" "}
                  </li>
                  <li>
                    <a href="#">About Us</a>{" "}
                  </li>
                </ul>
              </div>
              <div className="col-6 col-lg">
                <h4>Information</h4>
                <ul className="footerlinks">
                  <li>
                    <a href="#"> User Guide </a>{" "}
                  </li>
                  <li>
                    <a href="#">Contact Us</a>{" "}
                  </li>
                </ul>
              </div>

              <div className="col-6 col-lg">
                <h4>Legal</h4>
                <ul className="footerlinks">
                  <li>
                    <a href="#"> Privacy Policy </a>{" "}
                  </li>
                  <li>
                    <a href="#">Disclaimer</a>{" "}
                  </li>
                </ul>
              </div>

              <div className="col-6 col-lg">
                <h4>Registered Office</h4>
                <address>
                  905, 9th floor, Colonnade-2 Bh. Rajpath Club, Sarkhej -
                  Gandhinagar Hwy, Ahmedabad, Gujarat 380054 079-47554755
                </address>
              </div>
            </div>
          </div>
        </div>
        <hr className="horizantalline" />
        <div className="footercontainer copyrighttext pt-3">
          <div className="container-fluid">
            <div className="row">
              <div className="col-12 col-md text-center text-md-left">
                <p className="font-14  mb-0">
                  &copy; Veritas 2020 | All rights reserved
                </p>

                <p className="font-14  mb-0">
                  <span
                    style={{
                      fontWeight: "700",
                      fontFamily: "arial",
                      fontSize: "16px",
                    }}
                  >
                    <b>Veritas</b>
                  </span>{" "}
                  is a registered Trademark of Clarion Insurance Broking
                  Services Pvt. Ltd.
                </p>
              </div>
              <div className="col-12 col-md text-center text-md-right">
                <p className="font-14  mb-0">
                  <span
                    style={{
                      fontWeight: "700",
                      fontFamily: "arial",
                      fontSize: "16px",
                    }}
                  >
                    <b>Clarion Insurance Broking Services Pvt. Ltd.</b>
                  </span>{" "}
                </p>
                <p className="font-11  mb-0" style={{ fontSize: "12px" }}>
                  <span
                    style={{
                      fontWeight: "700",
                      fontFamily: "arial",
                      fontSize: "12px",
                    }}
                  >
                    IRDA Regn No:
                  </span>{" "}
                  712{" "}
                  <span
                    style={{
                      fontWeight: "700",
                      fontFamily: "arial",
                      fontSize: "12px",
                    }}
                  >
                    Regn Code:
                  </span>{" "}
                  IRDA/DB748/18{" "}
                  <span
                    style={{
                      fontWeight: "700",
                      fontFamily: "arial",
                      fontSize: "12px",
                    }}
                  >
                    Validity:
                  </span>{" "}
                  08-06-2020 to 07-06-2023
                </p>
              </div>
            </div>
            <div className="row">
              <div className="col-12 text-center text-md-right">
                <small className="poweredbytext">
                  Powered By{" "}
                  <a href="http://autotradetech.com/">
                    Automated Trading Softtech Pvt. Ltd.
                  </a>
                </small>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
};

export default Footer;
