import React from "react";
import { Link } from "react-router-dom";

function Home(props) {
  return (
    <>
      Home Compo
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/admin">Admin</Link>
        </li>
        <li>
          <Link to="/users">User</Link>
        </li>
      </ul>
    </>
  );
}

export default Home;
