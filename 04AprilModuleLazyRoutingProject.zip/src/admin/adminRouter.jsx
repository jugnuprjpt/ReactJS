import React from "react";
import { Routes, Route } from "react-router-dom";
import AdminDashboard from "./adminDashboard";
import AdminHeader from "./adminHeader.jsx";
import AllUsers from "./allusers.jsx";

function AdminRouter(props) {
  return (
    <>
      <Routes>
        <Route path="/" element={<AdminHeader />}>
          <Route index element={<AdminDashboard />} />
          <Route path="allusers" element={<AllUsers />} />
        </Route>
      </Routes>
    </>
  );
}

export default AdminRouter;
