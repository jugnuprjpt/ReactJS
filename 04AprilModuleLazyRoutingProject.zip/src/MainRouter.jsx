import React from "react";
import {
  BrowserRouter as Router,
  Routes,
  Route,
  Outlet,
  Link,
} from "react-router-dom";
import Home from "./Home.jsx";

const Admin = React.lazy(() => import("./admin/adminRouter.jsx"));
const UsersDashboard = React.lazy(() => import("./users/UserRouter.jsx"));

function MainRouter(props) {
  return (
    <>
      
      <Router>
        <Routes>
          <Route path="/">
            <Route index element={<Home />} />
            <Route
              path="admin/*"
              element={
                <React.Suspense fallback={<>...</>}>
                  <Admin />
                </React.Suspense>
              }
            />
            <Route
              path="users/*"
              element={
                <React.Suspense fallback={<>...</>}>
                  <UsersDashboard />
                </React.Suspense>
              }
            />
            <Route path="*" element={<NoMatch />} />
          </Route>
        </Routes>
      </Router>
    </>
  );
}

function NoMatch() {
  return (
    <div>
      <h2>Nothing to see here!</h2>
      <p>
        <Link to="/">Go to the home page</Link>
      </p>
    </div>
  );
}

export default MainRouter;
