import React from 'react';

function UserDashboard(props) {
    return (
        <div>
            UserDashboard
        </div>
    );
}

export default UserDashboard;