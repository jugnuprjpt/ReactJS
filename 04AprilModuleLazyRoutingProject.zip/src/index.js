import React from 'react';
import ReactDOM from 'react-dom';
import { createRoot } from "react-dom/client";
import './index.css';
import MainRouter from './MainRouter.jsx';
import '@fortawesome/fontawesome-free/css/all.min.css';
import 'bootstrap-css-only/css/bootstrap.min.css';
import 'mdbreact/dist/css/mdb.css';

const rootElement = document.getElementById("root");
const root = createRoot(rootElement);
root.render(<MainRouter />)
// ReactDOM.render(<MainRouter />,document.getElementById('root'));