// alert("Testing the alert");
// this is a command
// console.log("statement 1");

// console.log("statement 2");

// console.log(document.getElementById("blue_box").innerHTML);

// document.getElementById("blue_box").innerHTML = "<h1>Test</h1>";

// console.log(document.getElementById("blue_box").innerHTML);