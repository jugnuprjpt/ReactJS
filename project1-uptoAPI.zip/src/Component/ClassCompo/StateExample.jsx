import React, { Component } from 'react';


class StateExample extends Component {
    constructor() {
        super();
        this.state = { uname:'jugnu'}
        this.ChangeUserData = this.ChangeUserData.bind(this)
    }
      ChangeUserData(){
          this.setState({uname:'Rekha'});
      }
      
    
    render() {
        
        return (
            <>
                    User name: { this.state.uname }
                    <button onClick={this.ChangeUserData}>Click-Here</button>
            </>
        );
    }
}



export default StateExample;