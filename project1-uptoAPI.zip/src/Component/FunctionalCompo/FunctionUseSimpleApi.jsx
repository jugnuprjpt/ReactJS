import React, {useLayoutEffect, useState } from "react";
import axios from "axios";

function FunctionUseSimpleApi(props) {
  const [dispData, setDipsData] = useState("test");
  /* const [temp, setTemp] = useState("test"); */
  useLayoutEffect(() => {
    axios("https://reqres.in/api/users?page=2")
    .then (function (
      response
    ) {
      const ResData = response.data.data.map((vals, keys) => {
        return <li key={keys}>{vals.email}</li>;
      });

      setDipsData(ResData);
     /*  setStatus(true); */
    });
  }, []);

  return (
    <div>
      API calling
      <table border = "1">
        <tr>
          <td>
      <ul> {dispData}</ul>
          </td>
        </tr>
      </table>
    </div>
  );
}

export default FunctionUseSimpleApi;
