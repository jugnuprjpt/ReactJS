import React, { useState } from 'react'

function FunctionStateHooks() {
    const [Count,SetCount] = useState (0);
    const [SetHide,HideShow] = useState (true);
  return (
    <>
       <button onClick={increment}>increment</button>
      
       <button onClick={()=>{SetCount(Count+20)}}>Click-me</button>
       <button onClick={Decrement}>Decrement</button>
       <button onClick={hideShow}>
       {SetHide?<>Show</>:<>Hide</>}
       </button>
       <button onClick={hideShow}>
       {SetHide?<>Show</>:<>Hide</>}
       </button>
      
       {SetHide?<><img src="./../../logo512.png" alt="" /></>:<><img src="./../../YCrh.gif" alt="" /></>}
       
       <h1><p>{Count}</p></h1>
       
    </>
  )
  function increment (){
      /* console.log("called") */
      SetCount(Count+20)
}
function Decrement (){
    /* console.log("called") */
    SetCount(Count-20)
}
function hideShow (){
    /* console.log("called") */
    HideShow (!SetHide)
}

}
export default FunctionStateHooks