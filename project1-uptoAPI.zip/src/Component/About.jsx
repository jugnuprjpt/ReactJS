import React from 'react';
import Header from './Header';


function About(props) {
    return (
        <>
            <Header/>
            <div className="container">
               <div className="row">
                   <div className="col">
                   <h1>About</h1>
                   </div>
               </div>
           </div>
        </>
    );
}

export default About;