import React from 'react';
import App from './Component/Myapp.jsx';
import ReactDOM from 'react-dom';
import './index.css';
/* import App from './App'; */
import '@fortawesome/fontawesome-free/css/all.min.css'; 
import'bootstrap-css-only/css/bootstrap.min.css'; 
import'mdbreact/dist/css/mdb.css';
import { BrowserRouter, Routes, Route,} from "react-router-dom";
import reportWebVitals from './reportWebVitals';
/* 
ReactDOM.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>, */
  ReactDOM.render(
    <React.StrictMode>
      <App />
    </React.StrictMode>,
  document.getElementById('root')
);


reportWebVitals();
