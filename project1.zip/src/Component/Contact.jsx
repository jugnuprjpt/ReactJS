import React from 'react'
import Header from './Header'


function Contact(props) {
  return (
    <>
        
        <Header/>
         <div className="container">
               <div className="row">
                   <div className="col">
                   <h1>Contact</h1>
                   </div>
               </div>
           </div>
        </>
  )
}



export default Contact
