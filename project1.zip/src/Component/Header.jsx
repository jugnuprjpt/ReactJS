import React from 'react';
import { MDBNavbar, MDBNavbarBrand, MDBNavbarToggler } from "mdbreact";
import { Link } from "react-router-dom";

const Header = () => {
    return (
        <>
        <MDBNavbar color="green" dark expand="md">
        <MDBNavbarBrand>
          <Link className="nav-link waves-effect white-text mt-2 text-transform:uppercase" to="/">Navbar    
            </Link>
        </MDBNavbarBrand>
        <MDBNavbarToggler  />
        <div className="collapse navbar-collapse" id="navbarSupportedContent">
        <ul className="navbar-nav mr-auto">
          <li className="nav-item active">
            <Link className="nav-link waves-effect waves-light" to="/">Home
              <span className="sr-only">(current)</span>
            </Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link waves-effect waves-light" to="/About">About</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link waves-effect waves-light" to="/contact">Contact</Link>
          </li>
          <li className="nav-item">
            <Link className="nav-link waves-effect waves-light" to="/Example">Example</Link>
               
          </li>
        </ul>
        <form className="form-inline">
          <div className="md-form my-0">
            <input className="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search"/>
          </div>
        </form>
      </div>
      </MDBNavbar>
      
        </>
    );
};

export default Header;