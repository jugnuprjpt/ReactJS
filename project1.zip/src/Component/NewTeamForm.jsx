import React from 'react';


function NewTeamForm(props) {
    return (
        <div>
            <h1>NewTeamForm</h1>
        </div>
    );
}

export default NewTeamForm;