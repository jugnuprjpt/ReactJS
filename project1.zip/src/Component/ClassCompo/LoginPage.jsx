import React, { Component } from "react";

class LoginPage extends Component {
  constructor(props) {
    super(props);
    this.state = {username: '', passward:""}
  }

  setData=(e)=>{
   /*  console.log(e);  */
    this.setState({
      username:e.target.value
    })
  }
  /* loginClick (){
    fetchdata("").then((response)=>{response}.json()}).then()
    
  } */
  render() {
    return (
      <>
        <div className="row ">
          <div className="col-md-4 offset-md-4 bg-primary">
            <div className="card-offset-md-4">
              <div className="card-header bg-success mt-3 ">Login-page</div>
                <div className="card-body">
                  <div className="row">
                    <div className="col ">
                      <input type="text" placeholder="Enter your name" onChange={this.setData} className="form-control"name="username"id="username"/>
                    </div>{this.state.username}
                  </div>
                  <div className="row mt-2">
                    <div className="col ">
                      <input type="text" placeholder="Passward" className="form-control" onChange = {(e)=>{this.setState({passward:e.target.value})}} name="Passward" id=""/>
                  </div> 
                </div>
                <div className="row mt-2">
                    <div className="col text-center ">
                  {JSON.stringify(this.state)}
                      <input type="button" onClick={this.loginClick}value="login" className="btn btn-danger" name="btn-login" id="btn-login"/>
                      <input type="button" value="cancel" className="btn btn-danger" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </>
    );
  }
}

export default LoginPage;
