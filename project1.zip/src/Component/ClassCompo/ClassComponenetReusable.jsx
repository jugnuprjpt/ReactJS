import React, { Component } from "react";
import Mycart from "./Mycart";

class ClassComponenetReusable extends Component {
  render() {
    return (
      <>
      <div className="row">
          <div className="col"><Mycart descr= "mafat na bhave" title="Product-2" price= "50"/></div>
          <div className="col"><Mycart descr= "mafat na bhave" title="Product-3" price= "50"/></div>
          <div className="col"><Mycart descr= "mafat na bhave" title="Product-1" price= "40"/></div>
          <div className="col"><Mycart descr= "mafat na bhave" title="Product-4" price= "40"/></div>
      </div>
       
      </>
    );
  }
}

export default ClassComponenetReusable;
