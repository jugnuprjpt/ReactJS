import React, { Component } from 'react';

class Mycart extends Component {
  render() {
    return (
        <div class="card">
        <img
          src={"https://images.pexels.com/photos/6822382/pexels-photo-6822382.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500"}
          class="card-img-top"
          alt="Fissure in Sandstone"
        />
        <div class="card-body">
          <h5 class="card-title">{this.props.title}</h5>
          <p class="card-text">
          {this.props.descr}
          </p>
          <p>
          &#163; {this.props.price}
          </p>
          <a href="#!" class="btn btn-primary">
            Button
          </a>
        </div>
      </div>
    );
  }
}

export default Mycart;
