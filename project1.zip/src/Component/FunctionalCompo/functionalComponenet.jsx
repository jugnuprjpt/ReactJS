import React from 'react'


function functionalComponenet(props) {
  return (
    <div>functionalComponenet</div>
  )
}


export default functionalComponenet
