import React from 'react'


function FunctionProps(props) {
  return (
    <>
      <div className="container">
          <div className="row">
              <div className="col-md-3">
              <CustomeCardComponent title="Mafat nathi paisa thase" imgpath="https://images.pexels.com/photos/11358782/pexels-photo-11358782.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500,h=300"/>
              </div>
              <div className="col-md-3">
              <CustomeCardComponent title="Mafat nathi paisa thase" imgpath="https://images.pexels.com/photos/11358782/pexels-photo-11358782.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500,h=300"/>
              </div>
              <div className="col-md-3">
              <CustomeCardComponent title="Mafat nathi paisa thase" imgpath="https://images.pexels.com/photos/11358782/pexels-photo-11358782.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500,h=300"/>
              </div>
              <div className="col-md-3">
              <CustomeCardComponent title="Mafat nathi paisa thase" imgpath="https://images.pexels.com/photos/11358782/pexels-photo-11358782.jpeg?auto=compress&cs=tinysrgb&dpr=1&w=500,h=300"/>
              </div>
          </div>
      </div>
    </>
  )
}
function CustomeCardComponent(props) {
    return (
      <>
        <div className="card">
        
        <img
          src={props.imgpath}
          class="card-img-top"
          alt="Fissure in Sandstone"
        />
        <div class="card-body">
          <h5 class="card-title">{props.title}</h5>
          <p class="card-text">
           Lorem ipsum dolor sit, amet consectetur adipisicing elit. Odit, quo.
          </p>
          
          <p>
          &#163; 500
          </p>
          <a href="#!" class="btn btn-primary">
            Button
          </a>
        </div>
      </div>
      </>
    )
  }
  


export default FunctionProps

