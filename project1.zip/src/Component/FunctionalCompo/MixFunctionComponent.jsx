import React from 'react'

const name = 'Jugnu prajapati';
const element = <h1>Hello! {name}</h1>;
function MixFunctionComponent(props) {
  return (
    <>
     FunctionComponent example
    
    <br />
    {element}
    </>
  )
}

export default MixFunctionComponent

