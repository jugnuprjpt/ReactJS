import React from 'react'
import { BrowserRouter, Routes, Route,} from "react-router-dom";
import Home from './Home.jsx';
import About from './About.jsx';
import Contact from './Contact.jsx';
import Example from './Example.jsx';
/* import NewTeam from './NewTeam.jsx'; */
import ClassComponenet from './ClassCompo/ClassComponenet.jsx';
import FunctionalComponenet from './FunctionalCompo/functionalComponenet.jsx';
import ClassComponenetConstruct from './ClassCompo/ClassComponenetConstruct.jsx'; 
import ClassComponenetReusable from './ClassCompo/ClassComponenetReusable.jsx';
import StateExample from './ClassCompo/StateExample.jsx';
import StateLifeCycle from './ClassCompo/StateLifeCycle.jsx';
import LoginPage from './ClassCompo/LoginPage.jsx';



function Myapp() {
  return (
    <>
      <BrowserRouter>
    <Routes>
      <Route path="/" element={<Home />}/>
      <Route path="/About" element={<About />}/>
      <Route path="/Contact" element={<Contact />}/>
      <Route path="/Example" element={<Example />}>             
         <Route path="ClassComponenet" element={<ClassComponenet/>}>
            <Route path="Construct" element={<ClassComponenetConstruct/>}/> 
            <Route path="reusableClasscompo" element={<ClassComponenetReusable/>}/> 
            <Route path="stateexample" element={<StateExample/>}/>
            <Route path="statelifecycle" element={<StateLifeCycle/>}/>
            <Route path="loginPage" element={<LoginPage/>}/>

        </Route>
      <Route path="functionalCompo" element={<FunctionalComponenet/>}/> 
      </Route>
    </Routes>
  </BrowserRouter>,
    </>
  )
}

export default Myapp;