
// import UserService from './../services/UserService.jsx';
import UserService from './../services/UserService';

export const retierveUsers = (formData) => async(dispatch)=> {
    console.log("retierveUsers",formData);
    try {
        // const res = await UserService.getAll();
        const res = await UserService.LoginUserData(formData);
        dispatch({ type: "RETRIEVE_USER",payload:res})
    } catch (error) {
        console.log(error);
    }

}