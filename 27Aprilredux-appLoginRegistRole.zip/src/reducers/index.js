import { combineReducers } from "redux";
import users from "./users.jsx";

console.log("reducer index.jsx called");
export default combineReducers({
  users
})