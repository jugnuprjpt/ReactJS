import { MDBBtn, MDBCard, MDBCardBody, MDBCardImage, MDBCardText, MDBCardTitle, MDBCol, MDBInput } from 'mdbreact';
import React, { useEffect, useState } from 'react';
import { useCookies } from 'react-cookie'
import { Link, useNavigate } from "react-router-dom";
import Header from './Header';
import "./custom.css";
import { useDispatch, useSelector } from 'react-redux';
import { retierveUsers } from './actions/users';



function Login(props) {
    const users = useSelector(state => state.users);
    // console.log(users);
    const dispatch = useDispatch();
    const [cookies, setCookie] = useCookies([])
    const [state, setState] = useState({});
    const navigate = useNavigate();
    function submitData(e) {
        dispatch(retierveUsers(state))
    }
    useEffect(() => {
        // console.log(users);
        // console.log(typeof users);
        // console.log(Object.keys(users).length);
        
        if (Object.keys(users).length > 0) {
            console.log(users.data.Data);
            if (users.data.Code == 1) {
                console.log("success");
                setCookie("isLogin","1",3600);
                setCookie("userid",users.data.Data[0].id,3600);
                // console.log(users.data.Data[0].role_id);
                if (users.data.Data[0].role_id == 1) {
                    console.log("admin");
                    navigate("/admin");
                    console.log("admin");
                } else {
                    navigate("/user");
                }
            } else {
                console.log("invalid user");
            }
        }
    })
    function clearForm(e) {
        // dispatch(retierveLoginUsers())
    }
    return (
        <>
            <Header />
            <div className="container">

                <div className="col-lg-6 offset-md-3 col-md-6 mt-5">

                    <div className="card card-cascade wider">

                        <div className="view view-cascade gradient-card-header peach-gradient">
                            <h2 className="h2-responsive mb-2">Login</h2>

                        </div>
                        <div className="card-body card-body-cascade">
                            <div className="row">
                                <div className="col">

                                    <MDBInput name="username" label="User Name" onChange={(e) => {
                                        setState({ ...state, [e.target.name]: e.target.value });
                                    }} autoComplete="off" icon="user" />

                                    <MDBInput type="password" name="password" label="Password" onChange={(e) => {
                                        setState({ ...state, [e.target.name]: e.target.value });
                                    }} icon="key" />

                                    {/* <MDBBtn color="primary">Primary</MDBBtn> */}
                                </div>
                            </div>
                            <div className="row mt-3">
                                <div className="col text-center">
                                    {/* <div>{JSON.stringify(state)}</div> */}
                                    <button className="btn btn-primary waves-effect waves-light" onClick={submitData}>Login</button>
                                    <button className="btn btn-danger waves-effect waves-light" onClick={clearForm}>Cancel</button>
                                </div>
                            </div>
                            <div className="row mt-3">
                                <div className="col text-center">
                                    <Link to="/registration"> Click here for new account</Link>
                                </div>
                            </div>

                        </div>
                    </div>

                </div>
            </div>
        </>
    );
}

export default Login;