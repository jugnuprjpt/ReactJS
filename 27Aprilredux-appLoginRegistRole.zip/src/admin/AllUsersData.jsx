import React from 'react';

function AllUsersData(props) {
    return (
        <>
            AllUsersData
        </>
    );
}

export default AllUsersData;