
import httpanything from "./../http-common";

const getAll = () =>{
    console.log("getAll");
    return httpanything.get("http://localhost/api/getallusers")
}
const LoginUserData = (Data) =>{
    return httpanything.post("http://localhost/api/login",Data)
}


const UserService = {
    getAll,
    LoginUserData
}
export default UserService;