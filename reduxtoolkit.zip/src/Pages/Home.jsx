import React from 'react'
import Products from '../Component/Products'


const Home = () => {
  return (
    <div>
        <h2 className='heading'><h4>Welcome to redux toolkit store</h4></h2>
        <section>
            <h3>Products</h3>
            <Products/>
        </section>
    </div>
  )
}

export default Home