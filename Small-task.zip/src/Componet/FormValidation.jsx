import React, { useState } from "react";

function AboutForm() {
  const [username, setUserName] = useState("");
  const [password, setPassword] = useState("");

  return (
    <div>
      <h1>Form-handling</h1>
      <b> User-name:-</b>{" "}
      <input
        type="username"
        name="Ajay"
        onChange={(e) => setUserName(e.target.value)}
      />
      <br />
      <label htmlFor="">{username}</label>
      <br /> <br />
      <b> Passward:-</b> &nbsp;{" "}
      <input
        type="passward"
        name="Ajay"
        onChange={(e) => setPassword(e.target.value)}
      /><br />
      <label htmlFor=""> {password}</label>
      <br /> <br />
      &nbsp; &nbsp; <button onClick={() => {}}>Submit</button>
    </div>
  );
}
export default AboutForm;
