import React from 'react'
import {useState} from 'react'


function DataPage(){
    const [data, setData]= useState(null)
    const [print, setPrint]= useState(false)
  
function GetData(val)

{
    
    setData(val.target.value)
    setPrint (false)
}
    return(

        <div>
            {
                print? <h1>{data}</h1> : null
            }
            
            <input type="text" onChange={GetData}/>
           <button onClick={()=>setPrint(true)}>Print Here</button>
        </div>

    );
}

export default DataPage