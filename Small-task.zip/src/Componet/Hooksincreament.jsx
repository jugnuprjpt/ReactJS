import React, { useState } from "react";

function Simple() {
  // const [count,setCount]= usestate(0)
  const [count ,setCount] = useState(0)
  return (
    <>
      <h1>Hooks example &nbsp; {count}</h1>
      {/* <button onClick={()=>{SetCount(Count+1)}}>Click-me</button> */}

      <button
        onClick={() => {
          setCount(count + 1)}}
      >
        clickme
      </button>
    </>
  );
}

export default Simple;
