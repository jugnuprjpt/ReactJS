import React from "react";

export class HideToggle extends React.Component {
  constructor() {
    super();

    this.state = { show: true };
  }
  render() {
    return (
      <div>
        {this.state.show ? <h1>Here you are shown HIDE and TOGGELE</h1> : null}
       {/*  <button
          onClick={() => {
            this.setState({ show: false });
          }}
        >
          Click-me
        </button> */}
        {/* <button
          onClick={() => {
            this.setState({ show: true });
          }}
        >
          Click-t
        </button> */}
        <button onClick={() => {this.setState({ show:!this.state.show})}}>
         Hide & Toggle
        </button>
      </div>
    );
  }
}
