import logo from './logo.svg';
import './App.css';
import Loader from './Componet/Loader.jsx'
import ProfileProps from './Componet/ProfileProps.jsx'
import ClassProps from './Componet/ClassProps.jsx'
import Class from './Componet/Class.jsx'
import ClassThis from './Componet/ClassThis.jsx'
import FunctionInc from './Componet/FunctionInc.jsx'
import IncrementMini from './Componet/IncrementMini.jsx'
import {HideToggle} from './Componet/HideToggle.jsx'
import MatRow from './Componet/OnTouch.jsx'
import Simple from "./Componet/Hooksincreament.jsx"
import AboutForm from "./Componet/FormValidation.jsx"
import ClickImage from "./Componet/ClickImage.jsx"
import ClickName from "./Componet/ClickName.jsx"
import MapFunction from "./Componet/MapFunction.jsx"
import DataMost from "./Componet/DataPrint.jsx"
import DataPage from "./Componet/DataPage.jsx"
import Login from "./Componet/Login.jsx"



function App() {
  return (
        <>
        
        <ClassProps text={{name:"my Friiend"}} data ="How are you"/>
        <br/><br/><br/><br/>
        <hr/>
        <Class/>
        <br/><br/><br/>
        <hr/>
       
       <FunctionInc/>
       <br/><br/><br/>
       <hr/>
       <IncrementMini/>
       <br/><br/><br/>
       <hr/>
       <HideToggle/>
       <br/><br/><br/>
       <hr/>
       <MatRow/>
       <br/><br/><br/>
       <hr/>
      <Simple/>
      <br/><br/><br/>
       <hr/>
      <AboutForm/>
      <br/>
       <hr/>
       <ClickImage/>
       <br/>
       <hr/>
       <ClickName/>
       <br/>
       <hr/>
       <MapFunction/>
       <br/>
       <hr/>
       <DataMost/>
       <br/>
       <hr/>
       <DataPage/>
       <br/>
       <hr/>
       <Login/>
        </>
      
        
  );
}
 

export default App;
