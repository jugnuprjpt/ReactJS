import React from 'react';

import HomePage from './pages/home';

const App = () => {
  return <HomePage />;
};

export default App;
