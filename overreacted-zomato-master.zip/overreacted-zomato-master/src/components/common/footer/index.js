import React from "react";

const Footer = () => {
  return (
    <div className="absolute-center max-width">Made with 🔥 by Overreacted</div>
  );
};

export default Footer;
