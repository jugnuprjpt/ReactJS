const Router = require("express");
const { upload, uploadImage } = require( "../controllers/userController.js");
const router = Router();

router.post("/upload", uploadImage, upload);
//router.get('/download',downloadImage)
module.exports = router;
