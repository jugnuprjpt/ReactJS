require("dotenv").config();

const express = require("express");
//import { createClient } from "redis";
//const fetch = require("node-fetch");

//dotenv.config();
const app = express();
const port = process.env.PORT || 5001;
// const redis_port = process.env.REDIS_PORT || 6397;
// const client = createClient(redis_port);
const userUpload = require("./routes/index");
const cors = require("cors");
app.use(
  cors({
    origin: true,
  })
);
app.options("*", cors());
app.use("/user", userUpload);
// const getRepos = async (req, res, next) => {
//   try {
//     console.log("Fetching data...");
//     const { username } = req.params;
//     const response = await import("node-fetch").then(
//       `https://api.github.com/users/${username}`
//     );
//     const data = response.data;
//     const repos = data.public_repos;
//     client.setEx(username, 3600, repos);
//     //console.log(repos);
//     res.send(data);
//   } catch (err) {
//     console.error(err);
//     res.status(500);
//   }
// };

// app.get("/repos/:username", getRepos);
app.listen(port, () => {
  console.log(`Server is running  ${port}`);
});
