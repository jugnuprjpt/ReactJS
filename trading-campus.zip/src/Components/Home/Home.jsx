import React from 'react'
import Header from '../Header/Header'
import SideBar from '../SideNavbar/SideBar'

function Home() {
  return (
      <>
      <Header/>
        <SideBar></SideBar>
      </>
  )
}

export default Home