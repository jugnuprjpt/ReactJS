import React from 'react'

import Header from '../Header/Header'

const Money = () => {
  return (
    <div>
      <Header></Header>
   
        
    </div>
  )
}

export default Money
