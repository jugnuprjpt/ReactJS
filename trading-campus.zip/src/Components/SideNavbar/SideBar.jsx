import React from "react";


import { ProSidebar, Menu, MenuItem, SubMenu  } from 'react-pro-sidebar';
import "./SideBar.scss"
import "./SideBar.css"
import { FaDesktop,FaExchangeAlt,FaNetworkWired,FaToolbox,FaAccessibleIcon,FaVectorSquare} from "react-icons/fa"

const SideBar = () => {
  return (

    <div style={{marginLeft:"-22px"}}>
    <ProSidebar >
    <Menu style={{color:"black", fontWeight:"bold"}} >
    <MenuItem icon={<FaDesktop />}>Dashboard</MenuItem>
    <MenuItem icon={<FaExchangeAlt />}>Trading</MenuItem>
    {/* <SubMenu title="Trading" icon={<FaHeart />}>
    
    </SubMenu> */}
    
    <SubMenu title="Algo studio" icon={<FaNetworkWired />} >
    <MenuItem>one leg strategy</MenuItem>
      <MenuItem>Two leg strategy</MenuItem>
      <MenuItem>Three leg strategy</MenuItem>
      <MenuItem>Basket strategy 2</MenuItem>
     
     
    </SubMenu>
    <SubMenu title="Option box" icon={<FaToolbox />}>
    <MenuItem>Option Market </MenuItem>
      <MenuItem>Vol Trading</MenuItem>
      <MenuItem>Greek Tracker</MenuItem>
      <MenuItem>Two Leg Spread Matrix</MenuItem>
      <MenuItem>Three Leg Spread Matrix</MenuItem>
      <MenuItem>Four Leg Spread Matrix</MenuItem>
      <MenuItem>Option Strategy Box</MenuItem>
     
    </SubMenu>
    <SubMenu title="Technical studio" icon={<FaAccessibleIcon />}>
      <MenuItem>MTChart</MenuItem>
      
    </SubMenu>
    
    
    <SubMenu title="Screeners" icon={<FaVectorSquare />}>
      <MenuItem>Screener</MenuItem>
      <MenuItem>Customize Screener</MenuItem>
      
    </SubMenu>
  </Menu>
</ProSidebar>

    </div>
  );
};

export default SideBar;
