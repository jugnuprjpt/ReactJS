import React from "react";
// import {
//   ProSidebar,
//   SidebarHeader,
//   SidebarFooter,
//   SidebarContent,
// } from "react-pro-sidebar";

import { ProSidebar, Menu, MenuItem, SubMenu  } from 'react-pro-sidebar';
import "./SideBar.scss"
import {FaGem , FaHeart} from "react-icons/fa"

const SideBar = () => {
  return (

    <>
    <ProSidebar>
    <Menu iconShape="square">
    <MenuItem icon={<FaGem />}>Dashboard</MenuItem>
    <SubMenu title="Trading" icon={<FaHeart />}>
      <MenuItem>Component 1</MenuItem>
      <MenuItem>Component 2</MenuItem>
      <MenuItem>Component 2</MenuItem>
      <MenuItem>Component 2</MenuItem>
      <MenuItem>Component 2</MenuItem>
      <MenuItem>Component 2</MenuItem>
    </SubMenu>
    <SubMenu title="Chart" icon={<FaHeart />}>
      <MenuItem>Component 1</MenuItem>
      <MenuItem>Component 2</MenuItem>
      <MenuItem>Component 2</MenuItem>
      <MenuItem>Component 2</MenuItem>
      <MenuItem>Component 2</MenuItem>
    </SubMenu>
    <SubMenu title="Chart" icon={<FaHeart />}>
      <MenuItem>Component 1</MenuItem>
      <MenuItem>Component 2</MenuItem>
      <MenuItem>Component 2</MenuItem>
      <MenuItem>Component 2</MenuItem>
      <MenuItem>Component 2</MenuItem>
    </SubMenu>
    <SubMenu title="Chart" icon={<FaHeart />}>
      <MenuItem>Component 1</MenuItem>
      <MenuItem>Component 2</MenuItem>
      <MenuItem>Component 2</MenuItem>
      <MenuItem>Component 2</MenuItem>
      <MenuItem>Component 2</MenuItem>
    </SubMenu>
  </Menu>
</ProSidebar>
    </>
  );
};

export default SideBar;
