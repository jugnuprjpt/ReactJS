import React from "react";
import { Link } from "react-router-dom";
import "./Header.css";
import { Dropdown } from "react-bootstrap";

function Header() {
  return (
    <nav className="navbar navbar-expand-lg navbar-light bg-light">
      <Link to="/">
        <img
          src="Company-logo.png"
          alt="treading-campus-logo"
          className="logo" style={{width:"120px", height:"100px"}}
        />
      </Link>
      <button
        className="navbar-toggler"
        type="button"
        data-toggle="collapse"
        data-target="#navbarNav"
        aria-controls="navbarNav"
        aria-expanded="false"
        aria-label="Toggle navigation"
      >
        <span className="navbar-toggler-icon"></span>
      </button>
      <div className="collapse navbar-collapse" id="navbarNav">
        <ul className="navbar-nav ml-auto">
          <li className="navli  nav-item">
            <span className="nifty-bank">NIFTY BANK</span>
            <p className="digit">0000.0000(0.00%)</p>
          </li>
          <li className="navli  nav-item">
            <span className="nifty-bank">NIFTY50</span>
            <p className="digit">0000.0000(0.00%)</p>
          </li>
          <li className="navli nav-item ">
            <span className="nifty-bank">Total M2M</span>
            <p className="digit">0.00</p>
          </li>
          &nbsp; &nbsp; &nbsp; &nbsp;



          <p
            type="button"
            data-toggle="modal"
            data-target="#exampleModalCenter"
          >
            <li className="nav-item ">
              <Link to="/" className="nav-link">
                <i className="fa fa-inr " aria-hidden="true"></i>{" "}
                <span className="sr-only">(current)</span>
              </Link>
            </li>
          </p>
          <div
            className="modal fade"
            id="exampleModalCenter"
            tabIndex="-1"
            role="dialog"
            aria-labelledby="exampleModalCenterTitle"
            aria-hidden="true"
          >
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title" id="exampleModalLongTitle">
                    Trading currency
                  </h5>
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div className="modal-body">
                  <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Eos, nostrum?
                  </p>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    data-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
          <p
            type="button"
            data-toggle="modal"
            data-target="#exampleModalCenter1"
          >
            <li className="nav-item">
            <Link to="/" className="nav-link">
              <i className="fa fa-user" aria-hidden="true"></i>
            </Link>
          </li>
          </p>
          <div
            className="modal fade"
            id="exampleModalCenter1"
            tabIndex="-1"
            role="dialog"
            aria-labelledby="exampleModalCenterTitle"
            aria-hidden="true"
          >
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title" id="exampleModalLongTitle">
                use detail
                  </h5>
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div className="modal-body">
                  <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Eos, nostrum?
                  </p>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    data-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
          <p
            type="button"
            data-toggle="modal"
            data-target="#exampleModalCenter2"
          >
            <li className="nav-item">
            <Link to="/" className="nav-link">
              <i className="fa fa-share-alt" aria-hidden="true"></i>
            </Link>
          </li>
          </p>
          <div
            className="modal fade"
            id="exampleModalCenter2"
            tabIndex="-1"
            role="dialog"
            aria-labelledby="exampleModalCenterTitle"
            aria-hidden="true"
          >
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title" id="exampleModalLongTitle">
                   Connecting people
                  </h5>
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div className="modal-body">
                  <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Eos, nostrum?
                  </p>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    data-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
          
          
         
          <li className="nav-item">
            <Link to="/" className="nav-link ">
              <i className="fa fa-wifi" aria-hidden="true"></i>
            </Link>
          </li>
          <p
            type="button"
            data-toggle="modal"
            data-target="#exampleModalCenter3"
          >
            <li className="nav-item">
            <Link to="/" className="nav-link ">
              <i className="fa-solid fa-square-caret-right"></i>
            </Link>
          </li>
          </p>
          <div
            className="modal fade"
            id="exampleModalCenter3"
            tabIndex="-1"
            role="dialog"
            aria-labelledby="exampleModalCenterTitle"
            aria-hidden="true"
          >
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title" id="exampleModalLongTitle">
                   Active trading APP
                  </h5>
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div className="modal-body">
                  <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Eos, nostrum?
                  </p>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    data-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
          <p
            type="button"
            data-toggle="modal"
            data-target="#exampleModalCenter4"
          >
           <li className="nav-item">
            <Link to="/" className="nav-link ">
              <i className="fa fa-sign-in" aria-hidden="true"></i>
            </Link>
          </li>
          </p>
          <div
            className="modal fade"
            id="exampleModalCenter4"
            tabIndex="-1"
            role="dialog"
            aria-labelledby="exampleModalCenterTitle"
            aria-hidden="true"
          >
            <div className="modal-dialog modal-dialog-centered" role="document">
              <div className="modal-content">
                <div className="modal-header">
                  <h5 className="modal-title" id="exampleModalLongTitle">
                   Sign-out
                  </h5>
                  <button
                    type="button"
                    className="close"
                    data-dismiss="modal"
                    aria-label="Close"
                  >
                    <span aria-hidden="true">&times;</span>
                  </button>
                </div>
                <div className="modal-body">
                  <p>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                    Eos, nostrum?
                  </p>
                </div>
                <div className="modal-footer">
                  <button
                    type="button"
                    className="btn btn-secondary"
                    data-dismiss="modal"
                  >
                    Close
                  </button>
                </div>
              </div>
            </div>
          </div>
          
        </ul>
      </div>
    </nav>
  );
}

export default Header;
