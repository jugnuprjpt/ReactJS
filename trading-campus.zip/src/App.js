import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Money from './Components/HeaderComponent/money.jsx'
import Home from './Components/Home/Home';
function App() {
  return (
    <div className="cont">
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />}/>
        <Route path="money" element={<Money />}/>
          {/* <Route index element={<Home />} />
          <Route path="blogs" element={<Blogs />} />
          <Route path="contact" element={<Contact />} />
          <Route path="*" element={<NoPage />} /> */}
      </Routes>
    </BrowserRouter>
    </div>
    
  );
}

export default App;
