import logo from './logo.svg';
import './App.css';
import Header from './Component/Header';
import FixMenu from './Component/FixMenu';
import MenuBar from './Component/MenuBar';



function App() {
  return (
    <div className="App">
    {/*  <Header/>
     <FixMenu/>
     <MenuBar/> */}
    </div>
  );
}

export default App;
