import React from "react";
import Header from "./Header";
import FixMenu from "./FixMenu";
import MenuBar from "./MenuBar";
import { Outlet } from "react-router-dom";
import "./Hember.css";
// import { Dropdown } from "react-bootstrap";

function Hember(props) {
  return (
    <>
      <div>
        <Header />
      </div>
      <div className="d-flex">
        <div>
          <FixMenu />
        </div>
        <div>
          <MenuBar />
        </div>
      </div>
      {/* <Header />
      <FixMenu />
      <MenuBar />
    
     <Dropdown>
        <div className="fvrt">
        <Dropdown.Toggle className="jb" variant="success" id="dropdown-basic-mt" >
        Favarites
        </Dropdown.Toggle>
        </div>
        <Dropdown.Menu style={{border:"none",marginLeft:"30px",boxShadow:"none",top:"-7px"}}>
            <div className="submenu">
          <Dropdown.Item className="xx" href="#/action-1">Inbox</Dropdown.Item>
          <Dropdown.Item href="#/action-2">Sent-items</Dropdown.Item>
          <Dropdown.Item href="#/action-3">Drafts</Dropdown.Item>
          </div>
        </Dropdown.Menu>
      </Dropdown>
      <Dropdown>
        <div className="fvrt-one">
        <Dropdown.Toggle className="jb" variant="success" id="dropdown-basic-mt" >
        Folders
        </Dropdown.Toggle>
        </div>
        <Dropdown.Menu style={{border:"none",marginLeft:"30px",boxShadow:"none",top:"-7px"}}>
            <div className="submenu">
          <Dropdown.Item className="xx" href="#/action-1">Inbox</Dropdown.Item>
          <Dropdown.Item href="#/action-2">Junk-Email</Dropdown.Item>
          <Dropdown.Item href="#/action-3">Sent-items</Dropdown.Item>
          <Dropdown.Item href="#/action-4">Deleted-items</Dropdown.Item>
          <Dropdown.Item href="#/action-5">Archive</Dropdown.Item>
          <Dropdown.Item href="#/action-6">Notes</Dropdown.Item>
          <Dropdown.Item href="#/action-7">Conversion </Dropdown.Item>
          <Dropdown.Item href="#/action-8">Drafts</Dropdown.Item>
         
          </div>
        </Dropdown.Menu>
      </Dropdown>  */}
      <Outlet />

      {/*  <li className="function">
        <i class="fa-solid fa-greater-than"></i> &nbsp;
        <Link to="functioncomponent">
          <small>Favarites</small>
        </Link>
      </li>
      <li className="function">
        <i class="fa-solid fa-greater-than"></i> &nbsp;
        <Link to="functioncomponent"><small>Folders</small></Link>
      </li>
      <li className="function">
        <i class="fa-solid fa-greater-than"></i> &nbsp;
        <Link to="functioncomponent"><small>Groups</small></Link>
      </li>

      <Outlet /> */}
      <Outlet />
    </>
  );
}

export default Hember;
