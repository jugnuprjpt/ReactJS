import React from 'react';

function QrCode(props) {
    return (
        <>
            THis is QR code
        </>
    );
}

export default QrCode;