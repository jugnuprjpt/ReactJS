import React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Market from "./NIFTY";

function Dashboard() {
  return (
    <body>
      <div className="container-scroller">
        <nav className="navbar col-lg-12 col-12 p-0 fixed-top d-flex flex-row">
          <div className="navbar-brand-wrapper d-flex justify-content-center">
            <div className="navbar-brand-inner-wrapper d-flex justify-content-between align-items-center w-100">
              <a className="navbar-brand brand-logo" href="index.html">
                marketcap
              </a>
              <a className="navbar-brand brand-logo-mini" href="index.html"></a>
              <button
                className="navbar-toggler navbar-toggler align-self-center"
                type="button"
                data-toggle="minimize"
              >
                <span className="mdi mdi-sort-variant"></span>
              </button>
            </div>
          </div>
          <div className="navbar-menu-wrapper d-flex align-items-center justify-content-end">
            <ul className="navbar-nav mr-lg-4 w-100">
              <li className="nav-item nav-search d-none d-lg-block w-100">
                <div className="input-group">
                  <div className="input-group-prepend">
                    <span className="input-group-text" id="search">
                      <i className="mdi mdi-magnify"></i>
                    </span>
                  </div>
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Search now"
                    aria-label="search"
                    aria-describedby="search"
                  />
                </div>
              </li>
            </ul>
            <ul className="navbar-nav navbar-nav-right">
              <li className="nav-item dropdown me-1">
                <a
                  className="nav-link count-indicator dropdown-toggle d-flex justify-content-center align-items-center"
                  id="messageDropdown"
                  href="#"
                  data-bs-toggle="dropdown"
                >
                  <i className="mdi mdi-message-text mx-0"></i>
                  <span className="count"></span>
                </a>
                <div
                  className="dropdown-menu dropdown-menu-right navbar-dropdown"
                  aria-labelledby="messageDropdown"
                >
                  <p className="mb-0 font-weight-normal float-left dropdown-header">
                    Messages
                  </p>
                  <a className="dropdown-item">
                    <div className="item-thumbnail">
                      <img
                        src="images/faces/face4.jpg"
                        alt="image"
                        className="profile-pic"
                      />
                    </div>
                    <div className="item-content flex-grow">
                      <h6 className="ellipsis font-weight-normal">
                        Vishnu Prabhu
                      </h6>
                      <p className="font-weight-light small-text text-muted mb-0">
                        The meeting is cancelled
                      </p>
                    </div>
                  </a>
                  <a className="dropdown-item">
                    <div className="item-thumbnail">
                      <img
                        src="images/faces/face2.jpg"
                        alt="image"
                        className="profile-pic"
                      />
                    </div>
                    <div className="item-content flex-grow">
                      <h6 className="ellipsis font-weight-normal">
                        Mitesh Pandya
                      </h6>
                      <p className="font-weight-light small-text text-muted mb-0">
                        Masala dosa khane aana hai?
                      </p>
                    </div>
                  </a>
                  <a className="dropdown-item">
                    <div className="item-thumbnail">
                      <img
                        src="images/faces/face3.jpg"
                        alt="image"
                        className="profile-pic"
                      />
                    </div>
                    <div className="item-content flex-grow">
                      <h6 className="ellipsis font-weight-normal">
                        {" "}
                        Khemchand
                      </h6>
                      <p className="font-weight-light small-text text-muted mb-0">
                        Kya me Guru of react hun?
                      </p>
                    </div>
                  </a>
                </div>
              </li>
              <li className="nav-item dropdown me-4">
                <a
                  className="nav-link count-indicator dropdown-toggle d-flex align-items-center justify-content-center notification-dropdown"
                  id="notificationDropdown"
                  href="#"
                  data-bs-toggle="dropdown"
                >
                  <i className="mdi mdi-bell mx-0"></i>
                  <span className="count"></span>
                </a>
                <div
                  className="dropdown-menu dropdown-menu-right navbar-dropdown"
                  aria-labelledby="notificationDropdown"
                >
                  <p className="mb-0 font-weight-normal float-left dropdown-header">
                    Notifications
                  </p>
                  <a className="dropdown-item">
                    <div className="item-thumbnail">
                      <div className="item-icon bg-success">
                        <i className="mdi mdi-information mx-0"></i>
                      </div>
                    </div>
                    <div className="item-content">
                      <h6 className="font-weight-normal">Application Error</h6>
                      <p className="font-weight-light small-text mb-0 text-muted">
                        Just now
                      </p>
                    </div>
                  </a>
                  <a className="dropdown-item">
                    <div className="item-thumbnail">
                      <div className="item-icon bg-warning">
                        <i className="mdi mdi-settings mx-0"></i>
                      </div>
                    </div>
                    <div className="item-content">
                      <h6 className="font-weight-normal">Settings</h6>
                      <p className="font-weight-light small-text mb-0 text-muted">
                        Private message
                      </p>
                    </div>
                  </a>
                  <a className="dropdown-item">
                    <div className="item-thumbnail">
                      <div className="item-icon bg-info">
                        <i className="mdi mdi-account-box mx-0"></i>
                      </div>
                    </div>
                    <div className="item-content">
                      <h6 className="font-weight-normal">
                        New user registration
                      </h6>
                      <p className="font-weight-light small-text mb-0 text-muted">
                        2 days ago
                      </p>
                    </div>
                  </a>
                </div>
              </li>
              <li className="nav-item nav-profile dropdown">
                <a
                  className="nav-link dropdown-toggle"
                  href="#"
                  data-bs-toggle="dropdown"
                  id="profileDropdown"
                >
                  <span className="nav-profile-name">Kevin Patel</span>
                </a>
                <div
                  className="dropdown-menu dropdown-menu-right navbar-dropdown"
                  aria-labelledby="profileDropdown"
                >
                  <a className="dropdown-item">
                    <i className="mdi mdi-settings text-primary"></i>
                    Settings
                  </a>
                  <a className="dropdown-item">
                    <i className="mdi mdi-logout text-primary"></i>
                    Logout
                  </a>
                </div>
              </li>
            </ul>
            <button
              className="navbar-toggler navbar-toggler-right d-lg-none align-self-center"
              type="button"
              data-toggle="offcanvas"
            >
              <span className="mdi mdi-menu"></span>
            </button>
          </div>
        </nav>
        <div className="container-fluid page-body-wrapper">
          <nav className="sidebar sidebar-offcanvas" id="sidebar">
            <ul className="nav">
              <li className="nav-item">
                <a className="nav-link" href="index.html">
                  <i className="mdi mdi-home menu-icon"></i>
                  <span className="menu-title">Dashboard</span>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="nav-link"
                  data-bs-toggle="collapse"
                  href="#ui-basic"
                  aria-expanded="false"
                  aria-controls="ui-basic"
                >
                  <i className="mdi mdi-circle-outline menu-icon"></i>
                  <span className="menu-title">UI Elements</span>
                  <i className="menu-arrow fas fa-angle-down"></i>
                </a>
                <div className="collapse" id="ui-basic">
                  <ul className="nav flex-column sub-menu">
                    <li className="nav-item">
                      {" "}
                      <a
                        className="nav-link"
                        href="pages/ui-features/buttons.html"
                      >
                        Buttons
                      </a>
                    </li>
                    <li className="nav-item">
                      {" "}
                      <a
                        className="nav-link"
                        href="pages/ui-features/typography.html"
                      >
                        Typography
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="pages/forms/basic_elements.html">
                  <i className="mdi mdi-view-headline menu-icon"></i>
                  <span className="menu-title">Form elements</span>
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="pages/charts/chartjs.html">
                  <i className="mdi mdi-chart-pie menu-icon"></i>
                  <span className="menu-title">Charts</span>
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="pages/tables/basic-table.html">
                  <i className="mdi mdi-grid-large menu-icon"></i>
                  <span className="menu-title">Tables</span>
                </a>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="pages/icons/mdi.html">
                  <i className="mdi mdi-emoticon menu-icon"></i>
                  <span className="menu-title">Icons</span>
                </a>
              </li>
              <li className="nav-item">
                <a
                  className="nav-link"
                  data-bs-toggle="collapse"
                  href="#auth"
                  aria-expanded="false"
                  aria-controls="auth"
                >
                  <i className="mdi mdi-account menu-icon"></i>
                  <span className="menu-title">User Pages</span>
                  <i className="menu-arrow"></i>
                </a>
                <div className="collapse" id="auth">
                  <ul className="nav flex-column sub-menu">
                    <li className="nav-item">
                      {" "}
                      <a className="nav-link" href="pages/samples/login.html">
                        {" "}
                        Login{" "}
                      </a>
                    </li>
                    <li className="nav-item">
                      {" "}
                      <a className="nav-link" href="pages/samples/login-2.html">
                        {" "}
                        Login 2{" "}
                      </a>
                    </li>
                    <li className="nav-item">
                      {" "}
                      <a
                        className="nav-link"
                        href="pages/samples/register.html"
                      >
                        {" "}
                        Register{" "}
                      </a>
                    </li>
                    <li className="nav-item">
                      {" "}
                      <a
                        className="nav-link"
                        href="pages/samples/register-2.html"
                      >
                        {" "}
                        Register 2{" "}
                      </a>
                    </li>
                    <li className="nav-item">
                      {" "}
                      <a
                        className="nav-link"
                        href="pages/samples/lock-screen.html"
                      >
                        {" "}
                        Lockscreen{" "}
                      </a>
                    </li>
                  </ul>
                </div>
              </li>
              <li className="nav-item">
                <a className="nav-link" href="documentation/documentation.html">
                  <i className="mdi mdi-file-document-box-outline menu-icon"></i>
                  <span className="menu-title">Documentation</span>
                </a>
              </li>
            </ul>
          </nav>

          <div className="main-panel">
            <div className="content-wrapper">
              <div className="row">
                <div className="col-md-12 grid-margin">
                  <div className="d-flex justify-content-between flex-wrap">
                    <div className="d-flex align-items-end flex-wrap">
                      <div className="me-md-3 me-xl-5">
                        <h2>Welcome back,</h2>
                        <p className="mb-md-0">
                          Your Option Trading Dashboard.
                        </p>
                      </div>
                      <div className="d-flex">
                        <i className="mdi mdi-home text-muted hover-cursor"></i>
                        <p className="text-muted mb-0 hover-cursor">
                          &nbsp;/&nbsp;Dashboard&nbsp;/&nbsp;
                        </p>
                        <p className="text-primary mb-0 hover-cursor">
                          Analytics
                        </p>
                      </div>
                    </div>
                    <div className="d-flex justify-content-between align-items-end flex-wrap">
                      <button
                        type="button"
                        className="btn btn-light bg-white btn-icon me-3 d-none d-md-block "
                      >
                        <i className="mdi mdi-download text-muted"></i>
                      </button>
                      <button
                        type="button"
                        className="btn btn-light bg-white btn-icon me-3 mt-2 mt-xl-0"
                      >
                        <i className="mdi mdi-clock-outline text-muted"></i>
                      </button>
                      <button
                        type="button"
                        className="btn btn-light bg-white btn-icon me-3 mt-2 mt-xl-0"
                      >
                        <i className="mdi mdi-plus text-muted"></i>
                      </button>
                      <button className="btn btn-primary mt-2 mt-xl-0">
                        Generate report
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="row">
                <div className="col-md-12 grid-margin stretch-card">
                  <div className="card">
                    <div className="card-body dashboard-tabs p-0">
                      <ul className="nav nav-tabs px-4" role="tablist">
                        <li className="nav-item">
                          <a
                            className="nav-link active"
                            id="overview-tab"
                            data-bs-toggle="tab"
                            href="#overview"
                            role="tab"
                            aria-controls="overview"
                            aria-selected="true"
                          >
                            Overview
                          </a>
                        </li>
                        <li className="nav-item">
                          <a
                            className="nav-link"
                            id="sales-tab"
                            data-bs-toggle="tab"
                            href="#sales"
                            role="tab"
                            aria-controls="sales"
                            aria-selected="false"
                          ></a>
                        </li>
                        <li className="nav-item">
                          <a
                            className="nav-link"
                            id="purchases-tab"
                            data-bs-toggle="tab"
                            href="#purchases"
                            role="tab"
                            aria-controls="purchases"
                            aria-selected="false"
                          ></a>
                        </li>
                      </ul>

                      <div className="tab-content py-0 px-0">
                        <div
                          className="tab-pane fade show active"
                          id="overview"
                          role="tabpanel"
                          aria-labelledby="overview-tab"
                        >
                          <Market></Market>
                        </div>
                        <div
                          className="tab-pane fade"
                          id="sales"
                          role="tabpanel"
                          aria-labelledby="sales-tab"
                        >
                          <div className="d-flex flex-wrap justify-content-xl-between">
                            <div className="d-none d-xl-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                              <i className="mdi mdi-calendar-heart icon-lg me-3 text-primary"></i>
                              <div className="d-flex flex-column justify-content-around">
                                <small className="mb-1 text-muted">
                                  Start date
                                </small>

                                <div className="dropdown">
                                  <a
                                    className="btn btn-secondary dropdown-toggle p-0 bg-transparent border-0 text-dark shadow-none font-weight-medium"
                                    href="#"
                                    role="button"
                                    id="dropdownMenuLinkA"
                                    data-bs-toggle="dropdown"
                                    aria-haspopup="true"
                                    aria-expanded="false"
                                  >
                                    <h5 className="mb-0 d-inline-block">
                                      26 Jul 2018
                                    </h5>
                                  </a>
                                  <div
                                    className="dropdown-menu"
                                    aria-labelledby="dropdownMenuLinkA"
                                  >
                                    <a className="dropdown-item" href="#">
                                      12 Aug 2018
                                    </a>
                                    <a className="dropdown-item" href="#">
                                      22 Sep 2018
                                    </a>
                                    <a className="dropdown-item" href="#">
                                      21 Oct 2018
                                    </a>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                              <i className="mdi mdi-download me-3 icon-lg text-warning"></i>
                              <div className="d-flex flex-column justify-content-around">
                                <small className="mb-1 text-muted">
                                  Downloads
                                </small>
                                <h5 className="me-2 mb-0">2233783</h5>
                              </div>
                            </div>
                            <div className="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                              <i className="mdi mdi-eye me-3 icon-lg text-success"></i>
                              <div className="d-flex flex-column justify-content-around">
                                <small className="mb-1 text-muted">
                                  Total views
                                </small>
                                <h5 className="me-2 mb-0">9833550</h5>
                              </div>
                            </div>
                            <div className="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                              <i className="mdi mdi-currency-usd me-3 icon-lg text-danger"></i>
                              <div className="d-flex flex-column justify-content-around">
                                <small className="mb-1 text-muted">
                                  Revenue
                                </small>
                                <h5 className="me-2 mb-0">$577545</h5>
                              </div>
                            </div>
                            <div className="d-flex py-3 border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                              <i className="mdi mdi-flag me-3 icon-lg text-danger"></i>
                              <div className="d-flex flex-column justify-content-around">
                                <small className="mb-1 text-muted">
                                  Flagged
                                </small>
                                <h5 className="me-2 mb-0">3497843</h5>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div
                          className="tab-pane fade"
                          id="purchases"
                          role="tabpanel"
                          aria-labelledby="purchases-tab"
                        >
                          <div className="d-flex flex-wrap justify-content-xl-between">
                            <div className="d-none d-xl-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                              <i className="mdi mdi-calendar-heart icon-lg me-3 text-primary"></i>
                              <div className="d-flex flex-column justify-content-around">
                                <small className="mb-1 text-muted">
                                  Start date
                                </small>
                                <div className="dropdown">
                                  <a
                                    className="btn btn-secondary dropdown-toggle p-0 bg-transparent border-0 text-dark shadow-none font-weight-medium"
                                    href="#"
                                    role="button"
                                    id="dropdownMenuLinkA"
                                    data-bs-toggle="dropdown"
                                    aria-haspopup="true"
                                    aria-expanded="false"
                                  >
                                    <h5 className="mb-0 d-inline-block">
                                      26 Jul 2018
                                    </h5>
                                  </a>
                                  <div
                                    className="dropdown-menu"
                                    aria-labelledby="dropdownMenuLinkA"
                                  >
                                    <a className="dropdown-item" href="#">
                                      12 Aug 2018
                                    </a>
                                    <a className="dropdown-item" href="#">
                                      22 Sep 2018
                                    </a>
                                    <a className="dropdown-item" href="#">
                                      21 Oct 2018
                                    </a>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                              <i className="mdi mdi-currency-usd me-3 icon-lg text-danger"></i>
                              <div className="d-flex flex-column justify-content-around">
                                <small className="mb-1 text-muted">
                                  Revenue
                                </small>
                                <h5 className="me-2 mb-0">$577545</h5>
                              </div>
                            </div>
                            <div className="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                              <i className="mdi mdi-eye me-3 icon-lg text-success"></i>
                              <div className="d-flex flex-column justify-content-around">
                                <small className="mb-1 text-muted">
                                  Total views
                                </small>
                                <h5 className="me-2 mb-0">9833550</h5>
                              </div>
                            </div>
                            <div className="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                              <i className="mdi mdi-download me-3 icon-lg text-warning"></i>
                              <div className="d-flex flex-column justify-content-around">
                                <small className="mb-1 text-muted">
                                  Downloads
                                </small>
                                <h5 className="me-2 mb-0">2233783</h5>
                              </div>
                            </div>
                            <div className="d-flex py-3 border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
                              <i className="mdi mdi-flag me-3 icon-lg text-danger"></i>
                              <div className="d-flex flex-column justify-content-around">
                                <small className="mb-1 text-muted">
                                  Flagged
                                </small>
                                <h5 className="me-2 mb-0">3497843</h5>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="row">
                <div className="col-md-12 stretch-card">
                  <div className="card">
                    <div className="card-body">
                      <p className="card-title">Recent Purchases</p>
                      <div className="table-responsive">
                        <table
                          id="recent-purchases-listing"
                          className="table table-striped"
                        >
                          <thead>
                            <tr>
                              <th>INDEX</th>
                              <th>LTP</th>
                              <th>Pervious Value </th>
                              <th>Price</th>
                              <th>Per%</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>Jeremy Ortega</td>
                              <td>Levelled up</td>
                              <td>Catalinaborough</td>
                              <td>$790</td>
                              <td>06 Jan 2018</td>
                            </tr>
                            <tr>
                              <td>Alvin Fisher</td>
                              <td>Ui design completed</td>
                              <td>East Mayra</td>
                              <td>$23230</td>
                              <td>18 Jul 2018</td>
                            </tr>
                            <tr>
                              <td>Emily Cunningham</td>
                              <td>support</td>
                              <td>Makennaton</td>
                              <td>$939</td>
                              <td>16 Jul 2018</td>
                            </tr>
                            <tr>
                              <td>Minnie Farmer</td>
                              <td>support</td>
                              <td>Agustinaborough</td>
                              <td>$30</td>
                              <td>30 Apr 2018</td>
                            </tr>
                            <tr>
                              <td>Betty Hunt</td>
                              <td>Ui design not completed</td>
                              <td>Lake Sandrafort</td>
                              <td>$571</td>
                              <td>25 Jun 2018</td>
                            </tr>
                            <tr>
                              <td>Myrtie Lambert</td>
                              <td>Ui design completed</td>
                              <td>Cassinbury</td>
                              <td>$36</td>
                              <td>05 Nov 2018</td>
                            </tr>
                            <tr>
                              <td>Jacob Kennedy</td>
                              <td>New project</td>
                              <td>Cletaborough</td>
                              <td>$314</td>
                              <td>12 Jul 2018</td>
                            </tr>
                            <tr>
                              <td>Ernest Wade</td>
                              <td>Levelled up</td>
                              <td>West Fidelmouth</td>
                              <td>$484</td>
                              <td>08 Sep 2018</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <footer className="footer">
              <div className="d-sm-flex justify-content-center justify-content-sm-between">
                <span className="text-muted text-center text-sm-left d-block d-sm-inline-block">
                  Copyright ©{" "}
                  <a href="#" target="_blank">
                    marketcap.com{" "}
                  </a>
                  2022
                </span>
                <span className="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">
                  Only the best{" "}
                  <a href="" target="_blank">
                    {" "}
                    Options Trading{" "}
                  </a>{" "}
                  Dashboard
                </span>
              </div>
            </footer>
          </div>
        </div>
      </div>

      <script src="vendors/base/vendor.bundle.base.js"></script>

      <script src="vendors/chart.js/Chart.min.js"></script>
      <script src="vendors/datatables.net/jquery.dataTables.js"></script>
      <script src="vendors/datatables.net-bs4/dataTables.bootstrap4.js"></script>

      <script src="js/off-canvas.js"></script>
      <script src="js/hoverable-collapse.js"></script>
      <script src="js/template.js"></script>

      <script src="js/dashboard.js"></script>
      <script src="js/data-table.js"></script>
      <script src="js/jquery.dataTables.js"></script>
      <script src="js/dataTables.bootstrap4.js"></script>

      <script src="js/jquery.cookie.js" type="text/javascript"></script>
    </body>
  );
}

export default Dashboard;
