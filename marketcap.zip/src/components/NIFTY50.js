import React from 'react'

function NIFTY50() {
  return (
    <div>
    
    
    </div>
  )
}

export default NIFTY50