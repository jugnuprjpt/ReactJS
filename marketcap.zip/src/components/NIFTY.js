import React, { Component } from "react";
import { w3cwebsocket as W3CWebSocket } from "websocket";
const client = new W3CWebSocket("ws://www.tradingcampus.net:17002");


class Market extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      NIFTY_BANK: null,
      NIFTY_50: null,
      NIFTY_BANK_change: null,
      NIFTY_BANK_diff: null,
      NIFTY_50_diff: null,
      NIFTY_50_change: null,
      NiftyColor: null,
      BankNiftyColor: null,
    };
  }
  componentDidMount() {
    var OldPriceNifty = 0;
    var OldPriceBankNifty = 0;

    client.onopen = () => {
      console.log("WebSocket Client Connected");
    };
    client.onmessage = (message) => {
      const latest_data = message.data.split("#");
      if (latest_data[3] === "NIFTY BANK") {
        this.setState(() => ({
          NIFTY_BANK_prev: parseFloat(latest_data[4] - latest_data[5]).toFixed(
            2
          ),
        }));
        var CurrentPriceBankNifty = parseFloat(latest_data[4].toString(2));

        if (OldPriceBankNifty < CurrentPriceBankNifty) {
          this.setState(() => ({
            NIFTY_BANK: latest_data[4].toString(2),
            NIFTY_BANK_change: parseFloat(latest_data[6]),
            NIFTY_BANK_diff: parseFloat(latest_data[4]),
            BankNiftyColor: 1,
          }));
        } else {
          this.setState(() => ({
            NIFTY_BANK: latest_data[4].toString(2),
            NIFTY_BANK_change: parseFloat(latest_data[6]),
            NIFTY_BANK_diff: parseFloat(latest_data[4]),
            BankNiftyColor: 0,
          }));
        }
        OldPriceBankNifty = CurrentPriceBankNifty;
      } else if (latest_data[3] === "NIFTY 50") {
        this.setState(() => ({
          NIFTY_50_prev: parseFloat(latest_data[4] - latest_data[5]).toFixed(2),
        }));
        var CurrentPriceNifty = parseFloat(latest_data[4].toString(2));

        if (OldPriceNifty < CurrentPriceNifty) {
          this.setState(() => ({
            NIFTY_50: latest_data[4].toString(2),
            NIFTY_50_change: parseFloat(latest_data[6]),
            NIFTY_50_diff: parseFloat(latest_data[7]),
            NiftyColor: 1,
          }));
        } else {
          this.setState(() => ({
            NIFTY_50: latest_data[4].toString(2),
            NIFTY_50_change: parseFloat(latest_data[6]),
            NIFTY_50_diff: parseFloat(latest_data[7]),
            NiftyColor: 0,
          }));
        }
        OldPriceNifty = CurrentPriceNifty;
      }

      this.setState((state, props) => ({
        data: latest_data,
      }));
    };
  }

  render() {
    return (
      <div className="d-flex flex-wrap justify-content-xl-between">
        <div className="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
          <i className=" me-3 icon-lg text-danger"></i>
          <div className="d-flex flex-column justify-content-around">
            <small className="mb-1 text-muted">NIFTY</small>
            <h4
              className="me-2 mb-0"
              style={
                this.state.NiftyColor === 1
                  ? { color: "green" }
                  : { color: "red" }
              }
            >
              {this.state.NIFTY_50}
            </h4>
            <div className="me-2 mb-0">
              {this.state.NIFTY_50_change >= 0 ? (
                <span style={{ color: "green" }}>
                  {this.state.NIFTY_50_prev}({this.state.NIFTY_50_change}%){" "}
                </span>
              ) : (
                <span style={{ color: "red" }}>
                  {this.state.NIFTY_50_prev}({this.state.NIFTY_50_change}%)
                </span>
              )}
            </div>
          </div>
        </div>
        <div className="d-flex border-md-right flex-grow-1 align-items-center justify-content-center p-3 item">
          <i className=" me-3 icon-lg text-danger"></i>
          <div className="d-flex flex-column justify-content-around">
            <small className="mb-1 text-muted">BANK NIFTY</small>
            <h4
              className="me-2 mb-0"
              style={
                this.state.BankNiftyColor === 1
                  ? { color: "green" }
                  : { color: "red" }
              }
            >
              {this.state.NIFTY_BANK}
            </h4>
            <div className="me-2 mb-0">
              {this.state.NIFTY_BANK_change >= 0 ? (
                <span style={{ color: "green" }}>
                  {this.state.NIFTY_BANK_prev}({this.state.NIFTY_BANK_change}%){" "}
                </span>
              ) : (
                <span style={{ color: "red" }}>
                  {this.state.NIFTY_BANK_prev}({this.state.NIFTY_BANK_change}%)
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Market;
