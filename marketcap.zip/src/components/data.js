import React, { Component } from "react";
import { w3cwebsocket as W3CWebSocket } from "websocket";

const client = new W3CWebSocket("ws://www.tradingcampus.net:17002");

class Market extends Component {
  constructor(props) {
    super(props);
    this.state = {
      data: [],
      NIFTY_BANK: null,
      NIFTY_50: null,
      NIFTY_BANK_change: null,
      NIFTY_BANK_diff: null,
      NIFTY_50_diff: null,
      NIFTY_50_change: null,
      NiftyColor: null,
      BankNiftyColor: null,
    };
  }
  componentDidMount() {
    var OldPriceNifty = 0;
    var OldPriceBankNifty = 0;

    client.onopen = () => {
      console.log("WebSocket Client Connected");
    };
    client.onmessage = (message) => {
      const latest_data = message.data.split("#");
      if (latest_data[3] === "NIFTY BANK") {
        var CurrentPriceBankNifty = parseFloat(latest_data[4].toString(2));

        if (OldPriceBankNifty < CurrentPriceBankNifty) {
          this.setState(() => ({
            NIFTY_BANK: latest_data[4].toString(2),
            NIFTY_BANK_change: parseFloat(latest_data[6]),
            NIFTY_BANK_diff: parseFloat(latest_data[4]),
            BankNiftyColor: 1,
          }));
        } else {
          this.setState(() => ({
            NIFTY_BANK: latest_data[4].toString(2),
            NIFTY_BANK_change: parseFloat(latest_data[6]),
            NIFTY_BANK_diff: parseFloat(latest_data[4]),
            BankNiftyColor: 0,
          }));
        }
        OldPriceBankNifty = CurrentPriceBankNifty;
      } else if (latest_data[3] === "NIFTY 50") {
        var CurrentPriceNifty = parseFloat(latest_data[4].toString(2));

        if (OldPriceNifty < CurrentPriceNifty) {
          this.setState(() => ({
            NIFTY_50: latest_data[4].toString(2),
            NIFTY_50_change: parseFloat(latest_data[6]),
            NIFTY_50_diff: parseFloat(latest_data[7]),
            NiftyColor: 1,
          }));
        } else {
          this.setState(() => ({
            NIFTY_50: latest_data[4].toString(2),
            NIFTY_50_change: parseFloat(latest_data[6]),
            NIFTY_50_diff: parseFloat(latest_data[7]),
            NiftyColor: 0,
          }));
        }
        OldPriceNifty = CurrentPriceNifty;
      }

      this.setState((state, props) => ({
        data: latest_data,
      }));
    };
  }

  render() {
    return (
      <div>
        <tr>
          <th>NIFTY BANk</th>
        </tr>
        {
          <th
            style={
              this.state.BankNiftyColor === 1
                ? { color: "green" }
                : { color: "red" }
            }
          >
            <th>{this.state.NIFTY_BANK}</th>
          </th>
        }
        {this.state.NIFTY_BANK_change >= 0 ? (
          <th style={{ color: "green" }}>
            <th> ({this.state.NIFTY_BANK_change}%) </th>
          </th>
        ) : (
          <th style={{ color: "red" }}>
            <th> ({this.state.NIFTY_BANK_change}%) </th>
          </th>
        )}
        <tr>
          <th>NIFTY 50</th>
        </tr>
        {
          <th
            style={
              this.state.NiftyColor === 1
                ? { color: "green" }
                : { color: "red" }
            }
          >
            <th>{this.state.NIFTY_50}</th>
          </th>
        }
        {this.state.NIFTY_50_change >= 0 ? (
          <th style={{ color: "green" }}>
            <th> ({this.state.NIFTY_50_change}%) </th>
          </th>
        ) : (
          <th style={{ color: "red" }}>
            <th> ({this.state.NIFTY_50_change}%) </th>
          </th>
        )}
      </div>
    );
  }
}

export default Market;
