//import logo from './logo.svg';
// import './App.css';
import './components/css/materialdesignicons.css'
import './components/css/marketStyle.css'
import 'bootstrap/dist/css/bootstrap.min.css';
import Dashboard from './components/Dashboard';

function App() {
  return (
    <div className="App">
     <Dashboard></Dashboard>
    </div>
  );
}

export default App;
