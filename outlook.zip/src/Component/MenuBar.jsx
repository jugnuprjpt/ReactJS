import React from "react";
import "./MenuBar.css";
// import { Link } from "react-router-dom";

import {Dropdown} from 'react-bootstrap'

function MenuBar(props) {
  return (
    <>
       <div className="container ">
        <div className="row">
          <div className="col">
            <div className="logo-icon">
              <i className="fa fa-bars" aria-hidden="true"></i>
            </div>
          </div>
        </div>
      </div>
      <div className="row ">
        <div className="col "> 
      {/* <ul>
            <li className="hoverme">
              <button className="button-drop">
                {" "}
                <Link to="functionhellojsrend ">New event</Link>
              </button>
              <ul className="child">
                <li className="hoverme">
                  <ul className="child">
                  </ul>
                </li>
                <li className="test">test2</li>
                <li className="test">test2</li>
                <li className="test">test2</li>
                <li className="test">test2</li>
              </ul>
            </li>
          </ul> */}
      <Dropdown>
        <Dropdown.Toggle variant="success" id="dropdown-basic">
          New event
        </Dropdown.Toggle>

        <Dropdown.Menu>
          <Dropdown.Item href="#/action-1">Action</Dropdown.Item>
          <Dropdown.Item href="#/action-2">Another action</Dropdown.Item>
          <Dropdown.Item href="#/action-3">Something else</Dropdown.Item>
        </Dropdown.Menu>
      </Dropdown>
       </div>
      </div> 
    </>
  );
}

export default MenuBar;
