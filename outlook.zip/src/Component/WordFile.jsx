import React from 'react';
import Header from './Header';
import FixMenu from './FixMenu';
import MenuBar from './MenuBar';

function WordFile(props) {
    return (
        <>
            <Header/>
            <FixMenu/>
            <MenuBar/>
            <p>Hello all welcome to word file.Hello all welcome to word file. </p>      
        </>
    );
}

export default WordFile;