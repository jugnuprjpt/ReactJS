import React from 'react';
import Header from './Header';
import FixMenu from './FixMenu';
import MenuBar from './MenuBar';

function Check(props) {
    return (
        <>
             <Header/>
            <FixMenu/>
            <MenuBar/>
            <p>this check page so you are check it.this check page so you are check it </p>      
        </>
    );
}

export default Check;