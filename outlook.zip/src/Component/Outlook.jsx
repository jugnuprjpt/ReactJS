import React from 'react';
import FixMenu from './FixMenu';
import Header from './Header';
import MenuBar from './MenuBar';

function Outlook(props) {
    return (
        <>
    <Header/>
    <FixMenu/>
    <MenuBar/>
    </>
    
    );
}

export default Outlook;