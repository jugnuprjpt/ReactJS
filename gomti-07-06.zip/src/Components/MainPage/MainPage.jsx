import React from 'react'

const MainPage = () => {
  return (
    <>
      <div className="container-fluid" style={{background:"#ffd7b0", height:"650px"}} >
          <div className="row">
              <div className="col">
              </div>
          </div>

      </div>
    </>
  )
}

export default MainPage
