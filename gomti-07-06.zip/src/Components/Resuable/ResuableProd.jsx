import React from 'react'
import { useState } from 'react'
import ProductCard from '../ProductCard/ProductCard'
import ProductCardApi from '../../Api/ProductCardApi'


const ResuableProd = () => {
     const [cardProd, setCardProd] = useState(ProductCardApi)
  return (
    <>
   {/*     <div className="head mt-5">
          <h1>Our Service</h1>
      </div> */}
      <h1 style={{textAlign:"center",   marginTop:"30px",   /* padding:"20px" */ /* position:"relative" */}}>Product Buy</h1>
      <div className="container-fluid d-flex mt-2" /* style={{background:"black"}} */>
          <div className="row " style={{marginLeft:"5rem"}} >
              {cardProd.map((item)=> (
                  <ProductCard key = {item.id} title={item.title} source={item.image} description = {item.description}/>

              ))}
             
          </div>
      </div>
      
    </>
  )
}

export default ResuableProd