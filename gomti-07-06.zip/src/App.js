import './App.css';
import MyAppRouting from './Components/MyAppRouting';

function App() {
  return (
    <>
      <MyAppRouting></MyAppRouting>
    </>
  );
}

export default App;
