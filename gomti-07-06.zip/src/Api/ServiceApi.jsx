import React from 'react'
import commercial from '../img/commercial-review-pay.png'

const ServiceApi = [
    { id: 1, image: commercial, title: "Free Shipping", description:"On order above Rs 1000 only" },
    { id: 2, image: commercial, title: "Prime Quality", description:"100% Guarantee" },
    { id: 3, image: commercial, title: "Huge Savings", description:"At lowest price" },
    { id: 4, image: commercial, title: "Easy Returns", description:"@store" },
  ];

export default ServiceApi








