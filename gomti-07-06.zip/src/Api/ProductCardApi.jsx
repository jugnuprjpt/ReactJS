import React from 'react'
import dashboard from '../img/dashboard-health.png'

const ProductCardApi = [
    { id: 1, image: dashboard, title: "Free Shipping", description:"On order above Rs 1000 only" },
    { id: 2, image: dashboard, title: "Prime Quality", description:"On order above Rs 1000 only" },
    { id: 3, image: dashboard, title: "Huge Savings", description:"On order above Rs 1000 only" },
    { id: 4, image: dashboard, title: "Easy Returns", description:"On order above Rs 1000 only" },
    { id: 5, image: dashboard, title: "Free Shipping", description:"On order above Rs 1000 only" },
    { id: 6, image: dashboard, title: "Prime Quality", description:"On order above Rs 1000 only" },
    { id: 7, image: dashboard, title: "Huge Savings", description:"On order above Rs 1000 only" },
    { id: 8, image: dashboard, title: "Easy Returns", description:"On order above Rs 1000 only" },
    { id: 9, image: dashboard, title: "Free Shipping", description:"On order above Rs 1000 only" },
    { id: 10, image: dashboard, title: "Prime Quality", description:"On order above Rs 1000 only" },
    { id: 11, image: dashboard, title: "Huge Savings", description:"On order above Rs 1000 only" },
    { id: 12, image: dashboard, title: "Easy Returns", description:"On order above Rs 1000 only" },
  ];

export default ProductCardApi