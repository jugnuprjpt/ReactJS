/* import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';

const endPoint = new WebSocket('ws://tradingcampus.net:17001');

function App() {
  const BroadCastIP = 'ws://www.tradingcampus.net:17002';

  const bCastSocket = new WebSocket(BroadCastIP);

  bCastSocket.onopen = function(event) {
    console.log('Broadcast Socket Connected', event);
  };

  bCastSocket.onmessage = function(event) {
    console.log('Broadcast Socket Connected', event.data);
  };

  bCastSocket.onerror = function(event) {
    console.log('Error', event);
  };

  bCastSocket.onclose = function(event) {
    console.log('Broadcast Socket Disconnected.', event);
  };

  const socket = io(endPoint, { transports: ['websocket'] });

  const [isConnected, setIsConnected] = useState(socket.connected);
  const [lastPong, setLastPong] = useState(null);

  useEffect(() => {
    socket.on('connect', () => {
      setIsConnected(true);
    });

    socket.on('', data => {
      console.log(data);
    });

    socket.on('pong', () => {
      setLastPong(new Date().toISOString());
    });

    return () => {
      socket.off('connect');
      socket.off('disconnect');
      socket.off('pong');
    };
  }, []);

  const sendPing = () => {
    socket.emit('ping');
  };

  return (
    <div>
      <p>
        Connected: {'' + isConnected}
      </p>
      <p>
        Last pong: {lastPong || '-'}
      </p>
      <button onClick={sendPing}>Send ping</button>
    </div>
  );
}
export default App;
 */

import React from 'react';
import Connection from './component/connection/connection';
import SideBar from './component/Sidebar/Sidebar';
import Autoplay from "./component/Slider/Slider"
import Grid from "./component/Grid/Grid"
import TableButton from "./component/TableButton/TableButton"


function App() {
  return (
   <>
  <Connection/>
  <SideBar></SideBar>
  <Autoplay></Autoplay>
  <TableButton></TableButton>
  {/* <Grid></Grid> */}
  
    </>
  );
}

export default App;
