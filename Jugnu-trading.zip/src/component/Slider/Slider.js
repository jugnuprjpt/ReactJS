import React, { Component } from 'react';
import Slider from 'react-slick';

export default class AutoPlay extends Component {
  render() {
    const settings = {
      dots: false,
      infinite: true,
      slidesToShow: 8,
      slidesToScroll: 1,
      autoplay: true,
      speed: 2000,
      autoplaySpeed: 2000,
      cssEase: 'linear'
    };
    return (
      <div className="container-fluid slid-auto">
        {/* <h2>Auto Play</h2> */}
        <Slider {...settings}>
          <div>
            <span>Axics</span>
            <br />
            <span>12.54</span>
          </div>
          <div>
            <span>SBI</span>
            <br />
            <span>12.54</span>
          </div>
          <div>
            <span>Reliance</span>
            <br />
            <span>12.54</span>
          </div>
          <div>
            <span>Automated</span>
            <br />
            <span>12.54</span>
          </div>
          <div>
            <span>IBM</span>
            <br />
            <span>12.54</span>
          </div>
          <div>
            <span>PCBplanet</span>
            <br />
            <span>12.54</span>
          </div>
          <div>
            <span>Laxmi</span>
            <br />
            <span>12.54</span>
          </div>
          <div>
            <span>HDFC</span>
            <br />
            <span>12.54</span>
          </div>
          <div>
            <span>Axics</span>
            <br />
            <span>12.54</span>
          </div>
          <div>
            <span>Axics</span>
            <br />
            <span>12.54</span>
          </div>
        </Slider>
      </div>
    );
  }
}
