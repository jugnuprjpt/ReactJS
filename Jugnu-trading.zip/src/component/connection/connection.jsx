import React, { useEffect, useState } from 'react';
import Header from '../Header/Header';


const baseUrl = process.env.REACT_APP_baseUrl;
const interactive_socket = process.env.REACT_APP_interactive_socket;
const brodcast_socket = process.env.REACT_APP_brodcast_socket;
const strategt_socket = process.env.REACT_APP_strategt_socket;


console.log(baseUrl)
console.log(interactive_socket)
console.log(brodcast_socket)
console.log(strategt_socket)

const websocket=new WebSocket(`${baseUrl}${brodcast_socket}`)


function Connection() {

   const [Nifty,setNifty]= useState("")
    const [Nifty50, setNifty50] = useState("")
    
   useEffect(() => {
       websocket.onopen = (event)=> {
    console.log('Broadcast Socket Connected', event);
    };

    message()
    },[])

    const message = () => {
        websocket.onmessage = (event) => {
            const { data } = event
            const splt = data.split("#")
            console.log(data)

            splt.map((item, ind) => {
                if (item === "NIFTY BANK") {
                    const [, , , niftyName, niftyPrice, niftyDiff, niftyPer] = splt
                    setNifty({niftyName,niftyPrice,niftyPer,niftyDiff})
                }
                if (item === "NIFTY 50") {
                    const [, , , nifty50Name, nifty50Price,  nifty50Diff,nifty50Per] = splt
                        setNifty50({nifty50Name,nifty50Price,nifty50Per,nifty50Diff})
                }
                
            })
        };        

    }
    


    return (
        <>
            <Header data={{ Nifty, Nifty50 }}/>
            
    
        </>
    );
}

export default Connection;
