function TransCode() {
  this.PortFolioList = '1';
  this.StrategyPortFolio = '2';
  this.ScriptDeleteResponse = '3';
  this.ScriptDeleteRequest = '4';
  this.SaveColumnProfile = '5';
  this.ColumnProfileResponse = '6';
  this.SaveWorkspace = '7';
  this.WorkspaceResponse = '8';
  this.ErrorMsg = '9';
  this.ExchangeRequest = '10';
  this.ExchangeResponse = '11';
  this.InstrumentRequest = '12';
  this.InstrumentResponse = '13';
  this.SymbolRequest = '14';
  this.SymbolResponse = '15';
  this.ExpiryRequest = '16';
  this.ExpiryResponse = '17';
  this.StrikePriceRequest = '18';
  this.StrikePriceResponse = '19';
  //this.SeriesRequest = "20";
  this.SaveStrategyPortfolio = '20';
  //this.SeriesResponse = "21";
  this.StrategyPortFolioDetailRequest = '21';
  this.ContractAddRequest = '22';
  this.ContractAddResponse = '23';
  this.bestFiveRequest = '24';
  this.bestFiveResponse = '25';
  this.bestFiveDelete = '26';
  this.DownloadOrderPair = '27';
  this.SnapQuoteRequest = '28';
  this.SnapQuoteResponse = '29';
  this.PortFolioDetailRequest = '31';
  this.HistoryDataRequest = '33';
  this.HistoryDataResponse = '34';
  this.HistoryDownloadEnd = '35';
  this.PreferenceRequest = '36';
  this.PreferenceResponse = '37';

  this.ScriptSearchRequest = '42';
  this.ScriptSearchResponse = '43';
  this.ScriptSearchResponseEnd = '44';
  this.Nifty50Bse30Contract = '45';

  this.UserInfo = '47';
  this.OTPRequest = '48';
  this.OTPResponse = '49';
  this.OTPVerifyRequest = '50';
  this.OTPVerifyResponse = '51';

  this.LoginOTPRequest = '54';
  this.LoginOTPResponse = '55';
  this.MarketPictureAddRequest = '56';
  this.MarketPictureResponse = '57';

  this.MarginDetailRequest = '60';
  this.MarginDetailResponse = '61';

  this.AddUpdateStrategy = '65';
  this.StrategyDelete = '66';
  this.StrategyActiveDeactive = '67';
  this.StrategyDetails = '68';
  this.SetStrategyParameters = '69';
  this.SpreadUpdate = '70';
  this.SetArbitageParametes = '71';
  this.DownloadSpreadOrder = '72';
  this.SpreadOrder = '73';

  this.TemplateList = '74';
  this.TemplateAddReqResp = '75';
  this.TemplateDetailsReqResp = '76';

  this.MarketStatusResponse = '106';

  this.ChatMessageFromServer = '108';

  this.LoginRequest = '120';
  this.LoginResponse = '121';
  this.LogOffRequest = '122';
  this.LogOffResponse = '123';
  this.MappedClient = '126';

  this.DownloadRequest = '131';
  this.DownloadEnd = '134';
  this.UpdateTargetValues = '135';
  this.DeleteStrategyName = '136';

  this.DownloadOrder = '143';
  this.DownloadTrade = '144';
  this.DownloadNetPosition = '145';

  this.ChangePasswordRequest = '149';
  this.ChangePasswordResponse = '150';

  this.OrderEntryRequest = '151';
  this.OrderEntryConfirm = '152';
  this.OrderEntryError = '153';
  this.OrderEntryFreeze = '154';

  this.ModificationRequest = '161';
  this.ModificationConfirm = '162';
  this.ModificationError = '163';

  this.CancellationRequest = '166';
  this.CancellationConfirm = '167';
  this.CancellationFromExchange = '168';
  this.CancellationError = '169';

  this.OrderTrade = '200';
  this.StopLossTriggerNotification = '201';

  this.RMSRequest = '202';
  this.RMSResponse = '203';
  this.RMSUpdate = '204';

  this.MarketPicture = '300';
  this.DprChangeNotification = '301';
  this.IndexBroadcast = '302';

  this.bCastLoginRequest = '400';
  this.bCastLogoffRequest = '401';
  this.tokenAddRequest = '402';
  this.tokenDeleteRequest = '403';
  this.bCastLoginResponse = '404';
  this.bCastLogoffResponse = '405';

  this.IndexUpdate = '1303';
}

function UserRemarksEnums() {
  this.Trading = '0';

  // One Leg

  this.AdvancedJobber = '1';
  this.Scaling = '2';
  this.Arbitrage = '3';
  this.Scalping = '4';
  this.TrendJobber = '5';
  this.CalenderSpread = '6';
  this.OptionJobber = //TwoLeg
    '7';
  this.VolTrading = '8';
  this.PairTrading = '9';
  this.GreekTracker = '10';
  this.FourLegSpreadMatrix = '11';
  this.ThreeLegSpreadMatrix = '12';
  this.TwoLegSpreadMatrix = '13';
  this.CurrencySpread = '14';
  this.CashFuture = '15';
  this.RollSpread = '16';
  this.MegaVsMini = '17';
  this.BasketBankNiftyWatch = '18';
  this.BasketNifty = '19';
  this.LongShortCommodity = '20';
  this.LongShortEquity = '21';
  this.NiftyVSBankNifty = '22';
  this.OptionMarketWatch = '23';
  this.ThreeLegStrategy = '24'; //Three Leg Strategy

  //For optionBox Strategy
  this.OptionBoxStrategy = '25';

  // Other
  this.VolTradingTmp = '49';
  this.OptionMarketWatchTmp = '50';
  this.OneLeg = '51';
  this.TwoLeg = '52';
  this.ThreeLeg = '53';
  this.MtChart = '54';
  this.CustomizeScreener = '55';
  this.ThreeLegSpreadMatrixTmp = '56';
  this.FourLegSpreadMatrixTmp = '57';
  this.DummyTrade = '58';

  this.NetPosition = '59';
}

function Enums() {
  this.AdvancedJobber = '1';
  this.Scaling = '2';
  this.Arbitrage = '3';
  this.Scalping = '4';
  this.TrendJobber = '5';
  this.CalenderSpread = '6';
  this.OptionJobber = '7';
  this.VolTrading = '8';
  this.PairTrading = '9';
  this.GreekTracker = '10';
  this.FourLegSpreadMatrix = '11';
  this.ThreeLegSpreadMatrix = '12';
  this.TwoLegSpreadMatrix = '13';
  this.CurrencySpread = '14';
  this.CashFuture = '15';
  this.RollSpread = '16';
  this.MegaVsMini = '17';
  this.BasketBankNiftyWatch = '18';
  this.BasketNifty = '19';
  this.LongShortCommodity = '20';
  this.LongShortEquity = '21';
  this.NiftyVSBankNifty = '22';
  this.OptionMarketWatch = '23';
}

function OrderType() {
  this.None = 0;
  this.Index = 1;
  this.Stocks = 2;
}

export const transCode = new TransCode();
export const enums = new UserRemarksEnums();
export const BasketOrdType = new OrderType();
