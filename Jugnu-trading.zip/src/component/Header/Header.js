 import React, { useEffect, useState } from "react";
/* import AutoPlay from "../Slider/Slider"; */


const Header = ({ data }) => {

    const { niftyName, niftyPrice, niftyDiff,niftyPer } = data.Nifty;
    const { nifty50Name, nifty50Price, nifty50Diff, nifty50Per} = data.Nifty50;
    
    const [NiftyH, setNiftyH] = useState([]);
    const [Nifty50H, setNifty50H] = useState([]);

    
    useEffect(() => {
    setNiftyH((preNifty)=>[...preNifty,{ niftyName, niftyPrice, niftyDiff,niftyPer }])
    setNifty50H((preNifty50)=>[...preNifty50,{nifty50Name, nifty50Price, nifty50Diff, nifty50Per}])
},[data])

    const greenRedDiff1 = isNaN(niftyPrice-niftyDiff) ? "Loading...":(niftyPrice-niftyDiff).toFixed(2);
    const greenRed1 = (NiftyH.at(-1)?.niftyPrice >= NiftyH.at(-2)?.niftyPrice) ? "hr-pr-green" : "hr-pr-red";
    
    const greenRedDiff2 =  isNaN(nifty50Price-nifty50Diff) ? "Loading...":(nifty50Price-nifty50Diff).toFixed(2);
    const greenRed2 =( Nifty50H.at(-1)?.nifty50Price >= Nifty50H.at(-2)?.nifty50Price) ? "hr-pr-green" : "hr-pr-red";
  
  return (
      <>
  <nav className="navbar navbar-expand-lg navbar-light">
  <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span className="navbar-toggler-icon"></span>
  </button>
  <div className="collapse navbar-collapse " id="navbarTogglerDemo01" >
    <a className="navbar-brand" href="#"><img classname="logo" src="../img/automated_logo.png" alt="" /></a>
  
    
    <div className="nifty">
                      <span>{ niftyName}</span>
                      <br /> 
                      <span className={greenRed1}>{niftyPrice}</span>
                      &nbsp;&nbsp;
                      <span className={greenRed1}>{greenRedDiff1}</span>
                      &nbsp;&nbsp;
                      <span className={greenRed1}>({ niftyPer}%)</span>
        
    </div>
    <div className="fifty">
                      <span>{ nifty50Name}</span>
                      <br /> 
                      <span className={greenRed2}>{nifty50Price}</span>
                      &nbsp;&nbsp;
                      <span className={greenRed2}>{greenRedDiff2}</span>
                      &nbsp;&nbsp;
                      <span className={greenRed2}>({nifty50Per}%)</span>
        
    </div>
    <div className="Sensex">
    <span>Sensex</span>
          <br /> 
    <span>0.0000</span>
        
    </div>
    
  </div>
          </nav>

      {/* <AutoPlay data={{niftyName,niftyPrice,nifty50Name,nifty50Price} } /> */}
          
          
    </>
  );
};

export default Header; 
